import time


import json
from flet import *
import flet as ft
import flet
import socket
#from ClientHandler import Booking
#import ClientHandler


Boolean = {
    'Boolean1': True,
    'Boolean2': False
}

RecoverCli = {
    "Email" : None,
    "Password" :None
}

RecoverData = {
    'Code' : None,
    'New Password' : None
}

ClientInfo = {
    "Name": None,
    "Email": None,

}


x_ = {
    '_Lengh_to_loop' : None,
    '_Size_to_loop' : None
}
y_ = {
    'Size1_' : None,
    'Size2_' : None,
    'Size3_' : None,
    'Size4_' : None
}


Lengths = {
    'Length1_' : None,
    'Length2_' : None,
    'Length3_' : None,
    'Length4_' : None
}
_loginAcc = {
    "Email" : None,
    "Password" : None
}
initial = {

    'Email': None,
    'Password': None,

}
Create_Acc = {
    'Name': None,
    'Email': None,
    'Password': None,
    "Phone Number": None
}
Appointment = {
    'Style': 0,
    'Rows': 0,
    'Columns': 0,
    'Price' : 0,
    'Extra' : 0
}
__SetStyle_ = {
    'Style' : None, #1
    'Length' : None, #2
    'Time' : None, #3
    'Day' : None, #4
    'Month' : None, #5
    "Extra's" : None, #6
    "Color" : None, #8
    
}
_SetExtra_ = {
    "Goddess Curls (+R50)" : {'Price' : 50},
    "Clear Beads (+R30)" : {'Price' : 30},
    "Dreadlocks silver/gold beads (+R20)" : {'Price' : 20},
    "Rings (+R15)" : {'Price' : 15},
    "Curl Ends (+R20)" : {'Price' : 20}
}
_Styles = {
    'Knotless Braids' : {'Opt' : 0},
    'Butterfly Locs' : {'Opt': 1},
    'Brazilian Locs' : {'Opt': 2},
    'Brazilian Twist' : {'Opt': 3},
    'Normal Twist' : {'Opt' : 4},
    'Passion Twist' : {'Opt' : 5}
}
_Length = {
    'Waist Length': {'Row': 0},
    'Bum Length': {'Row': 1},
    'Below the ass': {'Row': 2},
    'Knee Length': {'Row': 3},
}
_Length2 = {
    'Armpit Length': {'Row': 0},
    'Waist Length': {'Row': 1},
    'Bum Length': {'Row': 2},
  
}
Sizes = {
    'Xsmall': {'column': 0},
    'Small': {'column': 1},
    'Medium': {'column': 2},
    'Large': {'column': 3}
}
_Size = {
    'Small': {'column': 0},
    'Medium': {'column': 1},
    'Large': {'column': 2}
}


Prices = [
    [
        
    [500 , 570, 620, 750],  # Xsmall Prices
    [450 , 500, 560, 680],  # Small Prices
    [420 , 470, 510, 610],  # Medium Prices
    [0   , 350, 410, 480]  # Large Prices
    
    ],
    
    [
    [580, 750, 850],
    [550, 720, 820],
    [0, 690, 790]
    ],
    
    [
    [450, 500, 560],
    [410, 470, 520]
    ],
    
    [
    [400, 480, 550, 720],
    [370, 450, 510, 680],
    [0, 350, 380, 430, 650]
    ],
    
    [
    [450, 540, 600, 700],
    [400, 480, 500, 620],
    [0, 420, 470, 520]
    ],
    
    [
    [690],
    [720]
    ],
]

#//?Account Handling
def CreateAcc(e):

    Name = Create_Acc["Name"]
    PhoneNumber = Create_Acc["Phone Number"]
    Email = Create_Acc["Email"]
    Password = Create_Acc["Password"]

    #ClientHandler.RegisterHandler(Name, Email, PhoneNumber, Password)
    pass
def RecoverUpd(e):
    Fill = e.control
    if Fill.label == 'Password':
        Passowrd = Fill.value
        RecoverData['New Password'] = Passowrd
        print(Passowrd)
    if Fill.label == 'Code':
        RecoverData['Code'] = Fill.value

    pass

#//?Appointment Booking

##//?Style
def _SetLength(e):
    print(e.control.value)

    for x, y in x_["_Lengh_to_loop"].items():
        if e.control.value == x:
            print("Its similar "+str(x))
            print("The Table_Int: "+str(y["Row"]))
            Appointment["Rows"] = y["Row"]
            __SetStyle_["Length"] = e.control.value
            break
            
        pass
    pass
def _SetSize(e):

    print("Its a drop down length")
    for x, y in x_['_Size_to_loop'].items():
            if e.control.value == x:
                print("Its similar "+str(x))
                print("The Table_Int: "+str(y["column"]))
                Appointment["Columns"] = y["column"]
                __SetStyle_["Size"] = e.control.value
                break
            pass
    pass
def _SetExtra(e):
    for x, y in _SetExtra_.items():
        if e.control.value == x:
            print("Its similar "+str(x))
            print("The Table_Int: "+str(y["Price"]))
            Appointment["Extra"] = y["Price"]
            __SetStyle_["Extra's"] = e.control.value
            
            print(Appointment["Extra"])
            break
        pass
def _SetColor(e):
    __SetStyle_["Color"] = e.control.value
    print(e.control.value)
    pass
def _SetSelect(e):
    step1_ = Prices[Appointment["Style"]]
    step2_ = step1_[Appointment["Columns"]]
    Price = step2_[Appointment["Rows"]]
    _c = 'R'
    x_ = Price+Appointment["Extra"]
    print(f"{_c}{x_}")
    pass
##//?Date
def _SetTime(e):
    __SetStyle_["Time"] = e.control.value
    pass
def _SetDay(e):
    __SetStyle_["Day"] = e.control.value
    pass
def _SetMonth(e):
    __SetStyle_["Month"] = e.control.value
    pass
def Check(e):
    Fill = e.control
    if Fill.label == 'Email':
        List = [Fill.value, Fill.suffix_text]
        Email = "".join(List)
        Create_Acc["Email"] = Email
        print(Email+': Is your Gmail account')

    if Fill.label == 'Password':
        Passowrd = Fill.value
        Create_Acc["Password"] = Passowrd
        print(Passowrd)
    if Fill.label == 'Number':
        Create_Acc["Phone Number"] = Fill.value

    if Fill.label == 'Name':
        Create_Acc["Name"] = Fill.value

    if Fill.label == 'Confirm Password':
        if Create_Acc["Password"] == Fill.value:
            pass

##//?Name//?Password
def _SetEmail(e):
    _loginAcc["Email"] = e.control.value
    print(e.control.value)
    pass

def _SetPassword(e):
    _loginAcc["Password"] = e.control.value
    print(e.control.value)
    pass

def _submit(e):
    #ClientHandler.LoginHandler(_loginAcc["Email"], _loginAcc["Password"])
    pass

def RecoverCheck(e):
    Fill = e.control
    if Fill.label == 'Email':
        RecoverCli["Email"] = Fill.value
        print(Fill.value+': Is your Gmail account')

    if Fill.label == 'New Password':
        Passowrd = Fill.value
        RecoverCli["Password"] = Passowrd
        print(Passowrd)






def LoginScreen(page: flet.Page):

    page.title = "Blue's Lavish Braids"
    
    _Dia = AlertDialog(
        modal=True,
        title=Text("Appointment Is Booked!", color=ft.colors.GREEN_200),
        content=ft.IconButton(ft.icons.CHECK_CIRCLE_OUTLINE, icon_color=ft.colors.GREEN_200, icon_size=15),
       
    )
    page.update()
    
    def RecvrFinalise(e):
        #ClientHandler.RecoverFinalise()
        pass
    def _SetStyle(e):
        if (e.control.text == 'Knotless Braids') or (e.control.text == 'Brazilian Twist') or (e.control.text == 'Normal Twist') or (e.control.text == 'Passion Twist'):
           __SetStyle_["Style"] = e.control.text
           
           print("It Supported for _Length")
           x_['_Lengh_to_loop'] = _Length
           
           Lengths["Length1_"] = 'Waist Length'
           Lengths["Length2_"] = 'Bum Length'
           Lengths["Length3_"] = 'Below the ass'
           Lengths["Length4_"] = 'Knee Length'
           
           y_["Size1_"] = '      '
           y_["Size2_"] = 'Small'
           y_["Size3_"] = 'Medium'
           y_["Size4_"] = 'Large'
           
               
        #//!Getting the Associated Value with the string in the table
           for i,v in _Styles.items():
                #//!Checking and get the Associated Value
               if e.control.text == i:
                  print("Its similar "+str(i))
                  print("The Table_Int: "+str(v["Opt"]))
                  Appointment["Style"] = v["Opt"]
        
        #//!Check if a style is different
           if e.control.text != 'Knotless Braids':
              x_['_Size_to_loop'] = _Size
              print('Its Supported for _Size')
            
              
              page.views.clear()
              page.views.append(BookingPg())
              page.update()
              
           else:
              print('Its Supported for Sizes')
              x_['_Size_to_loop'] = Sizes
              
              y_["Size1_"] = 'Xsmall'
              y_["Size2_"] = 'Small'
              y_["Size3_"] = 'Medium'
              y_["Size4_"] = 'Large'
            
              page.views.clear()
              page.views.append(BookingPg())
              page.update()
        elif (e.control.text == 'Butterfly Locs') or (e.control.text == 'Brazilian Locs'):
            x_['_Lengh_to_loop'] = _Length2
            x_['_Size_to_loop'] = _Size
        
            Lengths["Length1_"] = 'Armpit Length'
            Lengths["Length2_"] = 'Waist Length'
            Lengths["Length3_"] = 'Bum Length'
            Lengths["Length4_"] = '          '
            
            y_["Size1_"] = 'Xsmall'
            y_["Size2_"] = 'Small'
            y_["Size3_"] = 'Medium'
            y_["Size4_"] = 'Large'
            
            
           
            page.views.clear()
            page.views.append(BookingPg())
            page.update()
            print("Locs and _Size, _Length2")
        
        for i,v in _Styles.items():
            #//!Checking and get the Associated Value
            if e.control.text == i:
               print("Its similar "+str(i))
               print("The Table_Int: "+str(v["Opt"]))
               Appointment["Style"] = v["Opt"]
        pass
    def _SetAppoint(e):
        __Name = page.client_storage.get("Name")
        __Email = page.client_storage.get("Email")
        __Num = page.client_storage.get("Number")   
        
        Data = {'Name' : __Name, 'Email' : __Email,
                'Number' : str(__Num),'Day' : __SetStyle_["Day"],
                'Month' : __SetStyle_["Month"],'Time' :__SetStyle_["Time"],
                'Style' : __SetStyle_["Style"],'Size' : __SetStyle_["Size"], 
                'Length' : __SetStyle_["Length"], 'Extra' : __SetStyle_["Extra's"],
                'Colour' : __SetStyle_["Color"]
                }
        __json_Data = json.dumps(Data)
        print(__json_Data)
        #ClientHandler.Booking(__json_Data)
        
        page.dialog = _Dia
        _Dia.open = True
        page.update()
        time.sleep(4)
        _Dia.open = False
        page.update()
        page.go('/Main')
        page.update()
        
    def RecoverSubmit(e):
        #ClientHandler.RecoverHandler(RecoverCli['Password'], RecoverCli['Email'])
        page.dialog = RecvrAccDia
        RecvrAccDia.open = True
        page.update()
  
    def BookingPg():
        print("Hello world")
        
        
        return View(
            "/Book",
            padding=0,
            controls=[
                Container(
                    expand=True, width=2000, height=1000, gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=0), padding=0 ,content=Column(
                        scroll=True,
                        controls=[
                            Row([
                                TextButton("<", height=400, width=40),
                                Row([
                                    Image(src='https://media.discordapp.net/attachments/1114428377613467669/1142892018805264454/1692556872392.png?width=397&height=593', scale=1.12),
                                    Image(src='https://media.discordapp.net/attachments/1114428377613467669/1142892020243898398/1692556932404.png?width=414&height=593', scale=1.11),
                                    Image(src='https://media.discordapp.net/attachments/1114428377613467669/1142901122009403534/1692559161520.png?width=419&height=593', scale=1.12),

                                    Container(width=250, height=320, bgcolor=ft.colors.WHITE, border_radius=ft.border_radius.all(
                                        20), shadow=ft.BoxShadow(2, 10, color=ft.colors.BLACK45)),
                                    Container(width=250, height=320, bgcolor=ft.colors.WHITE, border_radius=ft.border_radius.all(
                                        20), shadow=ft.BoxShadow(2, 10, color=ft.colors.BLACK45)),
                                    Container(width=250, height=320, bgcolor=ft.colors.WHITE, border_radius=ft.border_radius.all(
                                        20), shadow=ft.BoxShadow(2, 10, color=ft.colors.BLACK45)),
                                    Container(width=250, height=320, bgcolor=ft.colors.WHITE, border_radius=ft.border_radius.all(
                                        20), shadow=ft.BoxShadow(2, 10, color=ft.colors.BLACK45)),
                                ], scroll=True, expand=True, spacing=100,run_spacing=100, alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER, offset=ft.Offset(x=0, y=0.1), height=350),
                                TextButton(">", height=400, width=40)
                            ],
                                vertical_alignment=ft.CrossAxisAlignment.START,



                            ),
                            Divider(color=ft.colors.PINK_200),
                            Text("--Style--", size=20, weight=ft.FontWeight.BOLD,
                                     color=ft.colors.WHITE, width=2000, text_align=TextAlign.CENTER),
                            ResponsiveRow([
                                
                                OutlinedButton('Knotless Braids', height=50,style=ButtonStyle(color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                                     shape=ft.RoundedRectangleBorder(radius=5), side=ft.BorderSide(2, ft.colors.WHITE, )), col={"xs": 4, "sm": 4, "md": 2, "lg": 2, "xl": 2},on_click=_SetStyle),
                                OutlinedButton('Butterfly Locs', height=50,style=ButtonStyle(color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                                     shape=ft.RoundedRectangleBorder(radius=5), side=ft.BorderSide(2, ft.colors.WHITE, )), col={"xs": 4, "sm": 4, "md": 2, "lg": 2, "xl": 2}, on_click=_SetStyle),
                                OutlinedButton('Brazilian Locs', height=50,style=ButtonStyle(color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                                     shape=ft.RoundedRectangleBorder(radius=5), side=ft.BorderSide(2, ft.colors.WHITE, )), col={"xs": 4, "sm": 4, "md": 2, "lg": 2, "xl": 2}, on_click=_SetStyle),
                                OutlinedButton('Brazilian Twist', height=50,style=ButtonStyle(color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                                     shape=ft.RoundedRectangleBorder(radius=5), side=ft.BorderSide(2, ft.colors.WHITE, )), col={"xs": 4, "sm": 4, "md": 2, "lg": 2, "xl": 2}, on_click=_SetStyle),
                                OutlinedButton('Normal Twist', height=50,style=ButtonStyle(color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                                     shape=ft.RoundedRectangleBorder(radius=5), side={ft.MaterialState.PRESSED : BorderSide(2, colors.PINK_200), ft.MaterialState.DEFAULT : BorderSide(2, ft.colors.WHITE)}), col={"xs": 4, "sm": 4, "md": 2, "lg": 2, "xl": 2}, on_click=_SetStyle),
                                OutlinedButton('Passion Twist', height=50,style=ButtonStyle(color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                                     shape=ft.RoundedRectangleBorder(radius=5), side={ft.MaterialState.PRESSED : BorderSide(2, colors.PINK_200), ft.MaterialState.DEFAULT : BorderSide(2, ft.colors.WHITE)}), col={"xs": 4, "sm": 4, "md": 2, "lg": 2, "xl": 2}, on_click=_SetStyle),
                                OutlinedButton('Knotless Bob Braids' ,height=50,style=ButtonStyle(color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                                     shape=ft.RoundedRectangleBorder(radius=5), side={ft.MaterialState.PRESSED : BorderSide(2, colors.PINK_200), ft.MaterialState.DEFAULT : BorderSide(2, ft.colors.WHITE)}), col={"xs": 4, "sm": 4, "md": 2, "lg": 2, "xl": 2}, on_click=_SetStyle),
                            ], alignment=ft.MainAxisAlignment.CENTER, width=2000),
                            Divider(color=ft.colors.PINK_200),
                            Column([
                                Text("--Length--", size=20, weight=ft.FontWeight.BOLD,
                                     color=ft.colors.WHITE, width=2000, text_align=TextAlign.CENTER),
                                ResponsiveRow([

                                    Dropdown(col={"xs": 4, "sm": 5, "md": 3, "lg": 3, "xl": 3}, width=200, border_color=ft.colors.WHITE, color=ft.colors.PINK_200, border_radius=20, hint_text='Size:',
                                             hint_style=ft.TextStyle(
                                        15, weight=FontWeight.BOLD, color=colors.WHITE),
                                        options=[
                                        ft.dropdown.Option(f"{y_['Size1_']}"),
                                        ft.dropdown.Option(f'{y_["Size2_"]}'),
                                        ft.dropdown.Option(f'{y_["Size3_"]}'),
                                        ft.dropdown.Option(f'{y_["Size4_"]}'),
                                    ],on_change=_SetSize),
                                    Dropdown(col={"xs": 4, "sm": 5, "md": 3, "lg": 3, "xl": 3}, width=200, border_color=ft.colors.WHITE, color=ft.colors.PINK_200, border_radius=20, hint_text='Length:',
                                             hint_style=ft.TextStyle(
                                        15, weight=FontWeight.BOLD, color=colors.WHITE),
                                        options=[
                                        ft.dropdown.Option(f"{Lengths['Length1_']}"),
                                        ft.dropdown.Option(f"{Lengths['Length2_']}"),
                                        ft.dropdown.Option(f"{Lengths['Length3_']}"),
                                        ft.dropdown.Option(f"{Lengths['Length4_']}"),
                                    ], on_change=_SetLength),
                                    Dropdown(col={"xs": 4, "sm": 5, "md": 3, "lg": 3, "xl": 3}, width=200, border_color=ft.colors.WHITE, color=ft.colors.PINK_200, border_radius=20, hint_text="Extras:",
                                             hint_style=ft.TextStyle(
                                        15, weight=FontWeight.BOLD, color=colors.WHITE),
                                        options=[
                                        ft.dropdown.Option("Goddess Curls (+R50)"),
                                        ft.dropdown.Option("Clear Beads (+R30)"),
                                        ft.dropdown.Option("Dreadlocks silver/gold beads (+R20)"),
                                        ft.dropdown.Option("Rings (+R15)"),
                                        ft.dropdown.Option("Curls Ends (+R20)")
                                        
                                    ],on_change=_SetExtra),
                                ], alignment=ft.MainAxisAlignment.CENTER),
                                
                                ResponsiveRow([
                                    TextField(col={"xs": 5, "sm": 5, "md": 3, "lg": 3, "xl": 3}, hint_text='Color',
                                              width=200, border_color=ft.colors.WHITE, color=ft.colors.PINK_200, border_radius=2, on_submit=_SetColor),
                                ], col=5, alignment=ft.MainAxisAlignment.CENTER),
                                
                                ResponsiveRow([
                                    TextButton("Select", style=ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.PINK_200}, color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                           shape=ft.RoundedRectangleBorder(radius=5)), col={"xs": 5, "sm": 5, "md": 3, "lg": 3, "xl": 3}, scale=0.8, height=50, on_click=_SetSelect),
                                ], col=5, alignment=ft.MainAxisAlignment.CENTER),
                                Divider(color=ft.colors.PINK_200),
                                Text("Date", size=20, weight=ft.FontWeight.BOLD,
                                     color=ft.colors.WHITE, width=2000, text_align=TextAlign.CENTER),
                                ResponsiveRow([

                                    Dropdown(col={"xs": 4, "sm": 5, "md": 3, "lg": 3, "xl": 3}, width=200, border_color=ft.colors.WHITE, color=ft.colors.PINK_200, border_radius=20, hint_text='Time:',
                                             hint_style=ft.TextStyle(
                                        15, weight=FontWeight.BOLD, color=colors.WHITE),
                                        options=[
                                        ft.dropdown.Option("7:30am"),
                                        ft.dropdown.Option("13:00pm"),

                                    ], on_change=_SetTime),
                                    Dropdown(col={"xs": 4, "sm": 5, "md": 3, "lg": 3, "xl": 3}, width=200, border_color=ft.colors.WHITE, color=ft.colors.PINK_200, border_radius=20, hint_text='Day:',
                                             hint_style=ft.TextStyle(
                                        15, weight=FontWeight.BOLD, color=colors.WHITE),
                                        options=[
                                        ft.dropdown.Option("1"),
                                        ft.dropdown.Option("2"),
                                        ft.dropdown.Option("3"),
                                    ], on_change=_SetDay),

                                    Dropdown(col={"xs": 4, "sm": 5, "md": 3, "lg": 3, "xl": 3}, width=200, border_color=ft.colors.WHITE, color=ft.colors.PINK_200, border_radius=20, hint_text="Month:",
                                             hint_style=ft.TextStyle(
                                        15, weight=FontWeight.BOLD, color=colors.WHITE),
                                        options=[
                                        ft.dropdown.Option("January"),
                                        ft.dropdown.Option("February"),
                                        ft.dropdown.Option("March"),
                                    ], on_change=_SetMonth),
                                ], col=5, alignment=ft.MainAxisAlignment.CENTER),
                                ResponsiveRow([
                                    TextButton("Book Appointment", style=ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.PINK_200}, color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                                     shape=ft.RoundedRectangleBorder(radius=5)), col={"xs": 7, "sm": 7, "md": 5, "lg": 5, "xl": 5}, scale=0.8, height=50, on_click=_SetAppoint),
                                ], col=5, alignment=ft.MainAxisAlignment.CENTER),

                            ])


                        ],

                    ),
                    
                ),

            ],  # View Control Table
            navigation_bar=ft.NavigationBar(
            destinations=[
            ft.NavigationDestination(icon=ft.icons.TRAVEL_EXPLORE_OUTLINED, label="Explore"),
            ft.NavigationDestination(icon=ft.icons.PERSON_2_OUTLINED, label="Profile"),
            ft.NavigationDestination(icon=ft.icons.BOOKMARK_BORDER_OUTLINED, selected_icon=ft.icons.BOOKMARK,label="History"),
        ], bgcolor=ft.colors.WHITE, height=55
            )

        )  # vIEW
    def MainPg():
        Size = 200
        Col_ = 12
        Price_Font = 'Anton'

        return View(
            "/main",
            [  # Control Start
                Row(controls=[
                    Container(expand=True, width=414, height=1000, gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=90), content=Column(
                        controls=[
                            Container(width=2000, gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=90), height=70,
                                      shadow=ft.BoxShadow(2, 10, color=ft.colors.BLACK45, blur_style=ft.ShadowBlurStyle.NORMAL),
                                      border_radius=ft.border_radius.only(0,0,20,20), content=Row([
                                          Icon(ft.icons.PERSON_2_OUTLINED,offset=ft.Offset(x=-0.60, y=0), size=40),
                                          Column([
                                          Text(size=22,text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan(f"{page.client_storage.get('Name')}",
                                                                 TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.BLACK26, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
                                          
                                          Text(f'{page.client_storage.get("Email")}', color=colors.WHITE, size=10, offset=ft.Offset(x=0, y=0)),
                                          
                                      ], spacing=1,alignment=MainAxisAlignment.CENTER, offset=ft.Offset(x=-0.2, y=0))
                                          ], alignment=ft.MainAxisAlignment.END)),
                            Image(src='https://media.discordapp.net/attachments/1114428377613467669/1142586446268600350/blue.png?width=883&height=497', fit=ft.ImageFit.FIT_HEIGHT),

                            Divider(color=ft.colors.PINK_400),
                            Text(size=35,text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("HairStyles",
                                                                 TextStyle(shadow=ft.BoxShadow(1,5,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffffff',
                                                                        ))]),
                                          
                            Row(
                                width=2000,height=400, controls=[
                                    Container(width=520, height=350, bgcolor=ft.colors.WHITE, margin=20, shadow=ft.BoxShadow(1, 20, color='#ff36fc', blur_style=ft.ShadowBlurStyle.NORMAL),
                                              border_radius=ft.border_radius.all(20), col={'xs': 2, 'sm': 8, 'md': 10, 'lg': 8, 'xl': 4},
                                              content=ft.Column(
                                                  controls=[
                                                       Text(size=30,text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Knotless Braids",
                                                                 TextStyle(shadow=ft.BoxShadow(0.2,20,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),
                                                      Text(width=414, height=20,
                                                           text_align=ft.TextAlign.JUSTIFY, size=15, weight=ft.FontWeight.BOLD, color='#f6b7ff'),
                                                      DataTable(
                                                          vertical_lines=ft.BorderSide(
                                                              2, '#f6b7ff'),
                                                          horizontal_lines=ft.BorderSide(2, '#f6b7ff'), columns=[
                                                              ft.DataColumn(
                                                                  ft.Text(" ", color="#f6b7ff", weight=ft.FontWeight.BOLD, size=0)),
                                                              ft.DataColumn(
                                                                    Text(size=18,text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Xsmall",
                                                                                TextStyle(shadow=ft.BoxShadow(0.02,40,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),
                                                                    ),
                                                              ft.DataColumn(
                                                                    Text(size=18,text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Small",
                                                                                TextStyle(shadow=ft.BoxShadow(0.02,40,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),
                                                                    ),
                                                              ft.DataColumn(
                                                                    Text(size=18,text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Medium",
                                                                                TextStyle(shadow=ft.BoxShadow(0.02,40,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),),
                                                              ft.DataColumn(
                                                                    Text(size=18,text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Large",
                                                                                TextStyle(shadow=ft.BoxShadow(0.02,40,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),),

                                                          ],
                                                          rows=[
                                                              DataRow(
                                                                  [
                                                                      ft.DataColumn(
                                                                         Text(text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Waist Length",
                                                                                TextStyle(shadow=ft.BoxShadow(0.02,50,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),
                                                                         
                                                                         ),
                                                                      ft.DataColumn(
                                                                          ft.Text("R500", color='#ffb0fe', size=18, font_family="Kanit")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R450", color='#ffb0fe', size=18, font_family="Kanit")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R420", color='#ffb0fe', size=18, font_family="Kanit")),
                                                                      ft.DataColumn(
                                                                          ft.Text("")),
                                                                  ]
                                                              ),
                                                              DataRow(
                                                                  [
                                                                      ft.DataColumn(
                                                                              Text(text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Bum Length",
                                                                                TextStyle(shadow=ft.BoxShadow(0.02,50,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),  
                                                                      ),
                                                                      ft.DataColumn(
                                                                          ft.Text("R570")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R500")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R470")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R350")),
                                                                  ]
                                                              ),
                                                              DataRow(
                                                                  [
                                                                      ft.DataColumn(
                                                                            Text(text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Below the ass",
                                                                                TextStyle(shadow=ft.BoxShadow(0.02,50,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),
                                                                        
                                                                        ),
                                                                      ft.DataColumn(
                                                                          ft.Text("R620")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R560")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R510")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R410")),
                                                                  ]
                                                              ),
                                                              DataRow(
                                                                  [
                                                                      ft.DataColumn(
                                                                            Text(text_align=TextAlign.CENTER,weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, spans=[ft.TextSpan("Knee Length",
                                                                                TextStyle(shadow=ft.BoxShadow(0.02,50,'#ff36fc', blur_style=ShadowBlurStyle.NORMAL),color='#ffb0fe',
                                                                        ))]),
                                                                            ),
                                                                      ft.DataColumn(
                                                                          ft.Text("R750")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R680")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R610")),
                                                                      ft.DataColumn(
                                                                          ft.Text("R480")),
                                                                  ]
                                                              )
                                                          ]
                                                      )
                                                  ]
                                    )
                                    )
                                ],
                                scroll=ft.ScrollMode.ALWAYS,
                                col={'xs': 2, 'sm': 8,
                                     'md': 10, 'lg': 8, 'xl': 4},
                            ),
                            Container(width=700, gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=90), height=70,
                                      shadow=ft.BoxShadow(2, 10, color=ft.colors.BLACK45, blur_style=ft.ShadowBlurStyle.NORMAL),
                                      border_radius=ft.border_radius.only(20,20,0 ,0), content=Row([
                                          
                                          TextButton("BOOK",style=ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.LIGHT_GREEN_500}, color={ft.MaterialState.DEFAULT: ft.colors.WHITE},
                                                                           shape=ft.RoundedRectangleBorder(radius=5),side=ft.BorderSide(2, ft.colors.LIGHT_GREEN_700)), col={"xs": 7, "sm": 7, "md": 5, "lg": 5, "xl": 5},height=45, width=150,on_click=lambda _:page.go('/Book')),
                                          ], alignment=ft.MainAxisAlignment.CENTER),),

                            
                        ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER, run_spacing=0, scroll=ft.ScrollMode.ADAPTIVE
                    ),
                        
                        col={'xs': 2, 'sm': 8, 'md': 10, 'lg': 8, 'xl': 4}
                    ),

                ]
                ),

            ],  # Control End
            scroll=True,
            padding=0




        )

    def LoginPg():
        return ft.View(route='/login',
                       controls=[
                           Image(src='https://media.discordapp.net/attachments/1114428377613467669/1142586446268600350/blue.png?width=883&height=497', width=2540, fit=ImageFit.FIT_WIDTH,),
                           
                           
                           Container(height=700, border_radius=ft.border_radius.only(20, 20, 0,0), width=2540, gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=90), offset=ft.Offset(x=0,y=-0.025),
                                     shadow=ft.BoxShadow(2,5,ft.colors.PINK_200, None, ft.ShadowBlurStyle.NORMAL),
                                     content=ft.ResponsiveRow([
                                          Text(size=40, text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Login",
                                                TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.PINK_300, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
                                          
                                          Text('Dont Have A Account?  ',size=15, text_align=TextAlign.CENTER, width=500, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Create Account",
                                                TextStyle(color=ft.colors.BLUE_500, decoration=TextDecoration.UNDERLINE),on_click=lambda e: page.go('/register'))]),
                                          
                                          
                                          Text(size=13,text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Email:",
                                                TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.BLACK26, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
                                          
                                          TextField(value=f'', border_radius=15, border_color=ft.colors.PINK_300, col={'xs': 12, 'sm': 8, 'md': 10, 'lg': 8, 'xl': 4}, scale=0.9,
                                                               text_style=ft.TextStyle(color=ft.colors.PINK_300), on_change=_SetEmail),
                                          
                                          Text(size=13,text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Password:",
                                                TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.BLACK26, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
                                          
                                          TextField(value=f'', border_radius=15, border_color=ft.colors.PINK_300, col={'xs': 12, 'sm': 8, 'md': 10, 'lg': 8, 'xl': 4}, scale=0.9, password=True, can_reveal_password=True,
                                                               text_style=ft.TextStyle(color=ft.colors.PINK_300), on_change=_SetPassword),
                                          TextButton("Enter", style=ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.PINK_300}, color={
                                                               ft.MaterialState.DEFAULT: ft.colors.WHITE}, shape=ft.RoundedRectangleBorder(radius=5)), col={'xs': 5.5, 'sm': 5.5, 'md': 8, 'lg': 8, 'xl': 8}, scale=0.8, height=50, on_click=_submit),
                                          
                                          Text('Forgot Password?  ',size=15, text_align=TextAlign.CENTER, width=500, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Recover Account",
                                                TextStyle(color=ft.colors.BLUE_500, decoration=TextDecoration.UNDERLINE),on_click=lambda e: page.go('/Recover'))]),
                                                
                                          
                                          Divider(color=ft.colors.WHITE, opacity=0.5),
                                          
                                          Text(size=18,text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, offset=ft.Offset(x=0, y=-1.55), color=ft.colors.WHITE, spans=[ft.TextSpan("Other Options",
                                                TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.BLACK26, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
                                          
                                          Row([
                                             Container(image_src='https://media.discordapp.net/attachments/1114428377613467669/1142616052182823033/kisspng-google-logo-5b02bbe1d5c6e0.2384399715269058258756.jpg?width=593&height=593', width=50, height=50,image_fit=ft.ImageFit.CONTAIN, bgcolor=ft.colors.WHITE, border_radius=ft.border_radius.all(20), border=ft.BorderSide(0.2, ft.colors.BLACK45),
                                                       shadow=BoxShadow(1,10, ft.colors.BLACK45, None, ShadowBlurStyle.NORMAL)), 
                                             Container(image_src='https://www.facebook.com/images/fb_icon_325x325.png', width=50, height=50,image_fit=ft.ImageFit.SCALE_DOWN, bgcolor='#4267B2', border_radius=ft.border_radius.all(20), border=ft.BorderSide(0.2, ft.colors.BLACK45),
                                                       shadow=BoxShadow(1,10, ft.colors.BLACK45, None, ShadowBlurStyle.NORMAL)),
                                             Container(image_src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAYAAACLz2ctAAAtXklEQVR4AezBAQ0AAAjAoNu/tDl0QAAAAAAAAG9NRy179gDrX9NdcfyzZ8793b9r27Zt2wqqoHYb1rYdt1Hj1AhqI6jdPrafizO7uHOSnfMi+uvFTlZm73XO9TdrZnK/TB6/Ctef5jqudm4MbgTXBofGUXAYHJaLvq/GUee4GR2tGz2tndaa80a2hWhAdCPCiAA0dBmBBQ1bH4BONqFJi8ggm6FrGWRnXKwxmrHS1kWsYYyDOBucdLk27Sycnod2cixOhzw7Fs8NnljFk8PZ01fFs087fRzPegmt+HP3uNvrF7325eD1lu6t1/SW2bxWX71x8iqRDskRjoNlqk9FoyW9yUjZQvYwgmxdIqMRzRoNNuiEjmYIIqQmNQQaltJvft/gFLnNDX3OIbLJ7FKIPBIjZAbTjzUYTeairawjGOToYm2chHG6cIa1y8eSe7r492Y8EM7/7Ez7rzf1mg8j3eUVKd1N9ZVXvUY786qteUfpnYKPkN5QuhaJokgCEEUNCbM34QlDQxhCCpu/gjb9xtTQUOHr6ucMCzbfXKN4Md+pMIbQ6rtzbnLO1Ln21QspdjPDBaT53138NeN3mvO/Pji+7xW95n04eTmAu/o8Lr3qVW++nnmj1ny08B6R3ly6DJEYhLnu4bPv9zCOCVAW+NjgaxID6QghN1AnHEOvMBTgluLt4eo28KI+n37Od7MAOHQNSQGvzb4CGGWtgDLUPlg79zTrn5G/162//4z1P/Cwu6DiHv/gTtYPXXnzj8nwYdL7S6/b0qtFIIkJm6TC15JaHQqE6h+spF2Xcs6b39VkTItkex/toi/gbT52oDW0CZitl5svsGy9nE5qWMQOMKImq6SAW1O5wvjCNbbPfTqs/975S/JXbzj/VTxyhxPw79yJ+porb/lOwee15qMNryNdikQWgCaEkpizCWAgC2hKH1BTrEC1zNSLDawCYNsDKAuYUYBlQYgKjIOgAlfTUmyfRxdy9il1sYdOg33i1c+/B466Fo0pQnIxn+L+kP/cjB++4t9+Eyd3CMBfdbvqy33U8ZVr3uucL4z0icHV2GCaYBlAywLclKyAAYGOKGogS/LVs9+qTfBM4FqBsU3IzHWhwBuipGDIOdNFScU9gAG7rbSeA4HYVAGsniFEAW0gNCkk068/nwmhzZt92a7PG3966vQHw8kf4H63seJpf+p21Ld4t9d03cdKXxe8uQRiEGqylXMeYi3PVQBfeGLsz0nNqtU0nOnX59z3aWctZ7cJZwGws9/6LKKAVS8eKbQdTKFJrSTh5sf0a5rZIBUlybBPPpA7GPdKrAIqjFKzPtT4le78m/EftzEB/9KtrPBO8Q3XvLX0tcJH49UlMWjq9nohaGP6VfUP/GLUqYmmGxiaUdJt1LSbIG694pkfF/UWLMo2u78Zd20DYoNM7OA0e+X2awO39HsQ61wvUknxxsTa7JXkI6zswdxAtEr5W+SPd9d/43ZsywvX3cr62uveE98ZvLdwsMHUaImYwAUxoIJHY5cEBKAVlWQoyTV0Y65ZUs0GqAWBmLAu5VmBtMC9hzxmHxobQOy2zQ3YCiepUdIaCPbPZIFYgc8ujbMmIxW0zdGo6VfW0OQH4fV48rVYfgHP3OIE/Bu3or7a218+vuGTpZ8P84JRoAJoFbpBjN35zy79CgTFL/2oAAprmdOypSETsGGRYurIoKRdLynSRAVYF0xvQlWSDxtYWgEidhenALETkPXzU8BUkpDcz4LiZz0DCuaawpBztUlOnf8SR1+Mh29hAp7dgvPeu1w5vILPaekbpEsRBCJQt9S5GrsLRdIrpFDhm4K2B3N3QyypNZUl8WYKTmjJAtiw1PcpICsA24ShFcBil3pRe+qtlro9S9if7+TuZ8MuxVRApdwl6/Y5kqKo0FH6+DTO/pHTn8F/3RIAb3bCfu+rvv/10xOfsaRvD149AogoIGUBcqWNDcjZ7858ClgNSt/ZATGmN0aT502eLPL5Lk/TOFt4Pi78sRgZcjTySGaTSbrw6bJAPdLs65bbNGFomkZJGtGY7wUiJkzRBTQyQosmG9nJQ4hLF2seB5dCLEFLIwJ250AAsgK+AwwGCLn1yJ0A9R3rVxOvyvrt+O9bAOBwM+uZUx/bYsKHTZIAtCAqaBt8Zd4lWvXOgoeDexb+Jbmn8dTCk8RzXTzfrKchnj/iJLVnunyuy/O0JrkGo4tMq8vkKZCLwBlIHEgO4OAUADFdDhKBVIuDI8Cp0zhsroMzZ3E014OG8yDi3HkPrR85tHB6vFquNC43ebxwPOQxcSXEFdZXaNorhnxL8nXxWuRlYBQIYZQ+i/aVRYGBuIxP4+ghjn4Yj7iJFelP3Kz6thvv/m5n/FGjB5Rz3P4/Gm0q7NOvbquexn0L/xn8Ef7mwJ/8J/dgeHkB+Cb/8uosb8r6/ng3vBnj1cnXICuMU1l6Zc6ptXjrXP0wH/h1OL/r/hf8Lde8re6HpA+NknaSmDJoCmQD6/RMKP+nvbsAsuS4En7/y6y63T2sscVMRsmklekz4zIzM++alzf8DIvGb3ntZd41My2ZmS1ZMglHjMPdfavyPLobcSNj6k231Hem50X/I9JZWdcjaWb+fbLOqcy8RMMefBIfSfxnw6dX/iC8wU+5fjMH70d5IL6HuBf9mUQzLeNEsqlWKumgn5a2p3sq/msNBXznGsj31BOb7EWJ74iwJcHUtBpBiinJpt9wFGIiZmY586+JdxY+cCs3YNkGdyMyfuJ4tj6A7htI3045qxKuuu6hjnwIdCifoPwsPrZGAr7d3eGnfc3o9O2+PfOX2JICpoUjBYFcJRmCpp+IyheDP5znjTu4Ab01YYPvJHHJiYzOZPnFlMfhUBJOtXock9YvEf9G+yzctgYC/oe7w28d96THN+HvU3FGSvifCAf/IyDERLhCiknrydyY+MfEi3GzmbLBz/jsFnwH/dOIB1JawnSjryJifd9BumfR/A2W3A3auzvDjXrflzgjBSYt+Z+ePB0Ro46Cbiv8Pv4y2GfmbPCnHrj/5/h7Pn496bnEo1FFvPj/aFA2kX6Cuffi80ctAr5k+5MeGsV7EpvS/0gGUMiTPiFNop9g8hy4C7/1U7wSYYOjwCfuS/+PlK869FQcA9lxZ3L9J/gFd4OWPe4qUfxEEzZJ1AJCE5QgIwc5kXqasBsvnecf/4GwwVHiqy7/QR/6Tfwu8WCmZQMD2XEgkL6XO5+Dxbsh4G6snpct/MgT5nhiQhRSIiEVpmUc1e96w0147k/wFwgbHGUe+Q4+fAfxvykPIzI9oAy0MOnvwfZn8u2/h7B6pLB6Xi3mbtrs5Sn5sQgLSbWkatKmi8uTscQf7eZXcNCas8Ezvbvl8QXFqnj3D5BeTjkeKAh0iCEBUT7M8ndil9Wj5R+tlju2uE/LIxULkKaXyBcgFUzX/oAvBr+zc83k2+BHvLvl+LPIj6C7F8edxqfvIK4gfwSfsiJueS0n3Jf4jfr57zDlmvNpvwZ/afVoaa2W1Dmn4XyJBIjpwnKaqgGaXBN4GW60hmxwwq9RvonxaaQt2ExZxh7KbYxfQ/c3uNowOO0gy39M/AJlx7CEdYISx1Eexc5/wNLqBbTdavhLX3vSiG+IsC0FEUAytZOtLsEg8erCW91tNvh+Ep+9AC8mvoaAaTFaYjNOJi6g+S76X2P5nVg0zI2MX0D8LjFHDwiUqkFB1+Iibn0wPrJ6Ad1qNcxxai4eHQGYFhASqQDQIrE38/pXcYM1YEPAz56G36U8GXWNDuoodT/S8xjdjvcxDPvfTvP9lItI9T8HtYSBOBfn88MfRaxSwB9cnYCNe0fvPEFKlCDXElKv5/vomA98G70N7hbf4/072fKDpKcQLQWgFqNuD6a8BA+HYfIV9K+iPIho6BEDq2QAbKW/iL99K+5cpYB/azXk/kceHswlCDIyYmB7IQ4kPnEJ11kDNthxOuMfJOZRiRCAGGpfRX4gPmuQrUvc8UnKtTi7WpwKCEBfCT4+EXfOdEn+HF8TyAAIqASckvLaxFsuplgDNlj8avL9KIgB6aD+HEpD+Wme8AsIg/zrpcxfQpxFn+hR/3N7FCT0iIfhFHxxdQKugjf7yc0tZ0NGVPIFciUjri9cYo3YoFwwLF2soJUL+MBW7DXI99zAqy8jPYV+nnoKdqhVMlspZ8HMIuAmzgo2FWRAqabfDIAEfBx3WCM2iJOGhTPdDxSO02b27MCwgN4epI8xvgWnD5dkahnLg/H3M9sTMuK+BRCVcBmBaRqM+Yg1ZINYImCVURCgD+bGDsuey4jbiNOHM2G15OfBzARsuH9jOPpFJR+6OAYFfLzntzxxJ8sn0J1EeybpfOJsnEyzhbSVmCN1OEDsJe0hfYX8JdI1uIXxjYx2Y681IT6PbyENyFeqe10lpi/x/lscnks478vEg6YEq/95VSJS7s0zE2IVAj7dSpnztJNV0tXPgYXpJOS2TexyjPBwb93JwoU88t4cfCjNA0kX0G8nIwH6gTO5AgkF+SBxC6P3Uz5N8wl8BVe7W5QPkfZQtquj23Ckmr73bi4qVsRtV2LgmY9DTM1n8+LN2L8KAV9sJVzqOXMjzquTj4I8rPzV1jkXeXXD9nPIT2busXQXEWeQNtNVUqmrnJWMaToz3EQ6k/77SN9FXE+5Fm+ifT+nfBKLVs1VHye/nfLdpAEpoK8kgbiNxTdaMeVSkuGl+lGPF0jHr1LAZCU0bJvjOFUZsq1ELEiA4ErrmAd59VZ2/CK+hTiP2EG0h87vA1DXAFLVZ6hp6c/EmaQL6Xex693EX+OTVset9K/Co4nTCBRAfV2P/THzt1gx+2+mQ1nhwoSCvMMqaAkrIbF9nvlUBfYetcKBhLQOp9/7+sSIvWcx/kG2/zDlLHowTKr6HpCqBqrPVJ+lHaQduAA/T7yS9FqWP4LdDk+H1+E4PJu4PzH0Cg4RlP3EbzP3Cqti6WYMRL4ykJAsn4nPrkLARSthM1sKTVRTboMYKEon9lhHnO9dW0jfhB+nfyxGFBh4omW41G7g84QwLKb6n/dTxBOZ/1PiDVY+a/w1i7dQXkicjy1EJYegfIzyRtJfs3yHVbG4l3mE4c3ttfjNCVZBS2MlNOxomB+uPEEoSAKhiH3WCed673l4GuPvxQnDZ6IEatJQZKtamRZw4CVlOdT4fMoL8D3EL+KjVkT7Zrov0T2O8hjiQspxpH3EV/BRvIM9l2LRqsn7h1ZEDz8P2rpKAXsrYYGtPaNAUSf+RZKEkIWEUIxYtA44zdvuw/yLiSdStgy/Sciokw1VRKsFrZ/7Sh3l6ux4oGgcW/Ew0h9R/pw7/gnLDs/luJodb2O8g36ebky5kxNuxz6Oc9f43BJ9ITKl2hNiYP/IeH4m2zLn2DoWIwghEDAZhYl4QhECSRxVAU/23/PEj9I8j+6kQz+k90iADlDLFnW0q8WqBE7V/TTV90iGSQ/Dg9j5ABb/DF9yeA6yfC2upUUL2OfusXSAdomyiVRHv4FIaPNM3gXPMUfJvZBMu19AL1Bk01OwJUeJk3xsK/13kX6H2AnUf4BQhkRAUlELWY3LgLihFnGYgHnS02jPIn4GtzgqfHSRh+8nNlWSGX43bG4mWXCxON9KuQGhTPUhZFAUoUGIEuKoCHgP795G87P0v0jsJAB1/m4Vz3x1qyVMA2MwICTDlAbfRtxG8zu4yhHnx3ou2Uscf4joNzSen8kzYKOMktQEQkgC5CkZCWXSB306CgJu8x9zLHwt/a9jO/3AEWSqWt40xbBYeXjZxWDtMCE5PAG1sN9Hl7jjN3CzI07spx8Qrr6H1QtYrISRMhfkiWAaTK6r/y0ClOVes98RJ/8Y49+nbAf6SQMoA283IEE9bRbSftxOvpP+StIdxD7yMrnFZspO0imkE0nbsRNzwyWbmgQOURbagh9nxyLxu7jeEWXXvrrkQgcDUs5IQEqbRGoUYCrpgDKRL5mMlMVWHHAEGXn3ReT/g7J9+Cd2qGqpyoZjiXQV5VLyJ3AJzRWcdDk6NW5pWLwnWy4gX0g8jHQf3B9bKMgwLKQ0VBpK+Bnsxm86opRu+NwYtXwo7YwEXG5JmQAUWSCEkGEiYRGwFEo5cvL99zmMns/4ZMrA0nGqzw6VTCzRf47mX0kfJ11G3Aws41oD9LiZ/Tfjv8nb2Xwy6VGUb8YT6LeTVjr9Vr2W8jTKu/BeR4wY061gCi6AaGeShNC15HyoZ6hUnbieBCwnpXdE+OI8fob+CRQUAHQoVXSpM9UMcID8+/SvYv+VPG0Z4a6xB3t4xZWc+F7KE/DTpItxuGRkoNRfthG/Oim5XOmI0HcUGBSvOnW1nUkSQpln3BAw8MK7TAlZlmh6M+e/R7TfTfMz9Fsoh4l41NMhcYD4N+LFuAxo8CfuPt2Y67+Cr+AvOen5xPeTziHl4cjHwL6Pp5Key95n4Q4zZ7w8sD1zoKRVmllNwQ0lkVBgOB0H/ZiDYeake1N+kNhen940vGgzoSDgKtp/Yv5Pcb2ZU36PuJz8y7iQaOsSDQWgvkY0eCJbH8kV70AxWwqljnrDPyCkGW1KGjeUVE+/hkschQgzp5s8X6kLowNLZ/O0iLfgl1l8G/Y7Itx+kP3/xoVfon8uvpEAVT+QFRc4k/gxzv4MrjNTLi8YXo5FNe5XGwG7VQgYiYCBkGw6AsXsBdw1R/l5+oYyvDFHqqMh3E7zq+x+PTpHlsIlH+fcp9OeiwtI9azCcFYMTyEeidcc6Qg4fNI+RJ5RErKcKYkY2nlVR6CgMzueknjRc2hOreUjBgrK0CHfSv+DvOs/0DlqvPtKfvTbGP0B/VORMTSj1AJsJ36bfW/FQTOjKwTDEa/+wUkzEnCpQaoLuZSBelBfEGbG755FfCNjFBiIFnVxOd1G/Cm3vIeHdI46n/4iD34p6QLSGQQMJFF1K/dm68PwHjMjKgHL4X5A0qySkEwkykAELNW9PujNjvSNjM+hh+FFAVQSegvNn3PPg9YNu9/H9j8g/QZlp2kUGK7DGf8wt70PxUzoAVBqCatmlknIUgJKbT76+g8HHZowEy7ZTHk45QTyQCG3ALIpxjQvoLvBuuL2JY77B7rH4RsBiBVUHOLBnHghPmsm3BlDq6AH9iWnGT8DFtONhA4JBWOAoJgN+x9CfhTy8JQbaNAjkArNCyhXWJd84WZOewZzT8BWyko3nd+Lpe9i9yUo1pjhVTAG6oBhRoXoA4mMfmhXPAJ9Jeda8+9znH0/ysmESRt4n9sBMspn8Vbrmmuu4Nx3EN+BoWhT/6VvpVzAju2405pzaxDqBkP3ZzUFO3QZpp/qTfXdjJ4Bd96T5YuJheHlVPXSqTQm/QP7v2Td0/8Z6bHEiYYjTl0YPoflc/Apa04fAMRK2sySkFS9dhvYoNyhwIyqA/M7WXooCeozuSohCxLSdbQfZmGfdU/+MuP3kL7zEAIOTXsnUE42E8LKBYQwqzIMukSYbnSgfg1GxGySkIMnEvcjIWD4iEyBHDSfYvFSxwQ7r+Pmd9B/AzYNr+yJ6Xunku7H1v/CkjUnqjZc9pphErI/kwY2KB9qDL0ZCHg67SYSDCyNzwBIeyZns+x2TPDfPff5Iul6nFdFuuEvmOZc9m1dewH7ICGqZrCf1btgBMpKzolDMRvKvRgPlJxyJWNG3IJPOaboryZfSTkPKCvIPMvkaBG3WXOGi8+kIzUFj4cPpdHX0/AMBezOJw1MtwW5zoj3E19yTLH3FrZeg57SAFG3eja6B2nBmhPD8lHdM8sIeBDQVxKODe8ZXbb2jE8CciVcroTMKChX849fdGyxyO9dTTpAbKMADEU/lJOIzdacWjrDEW+2Ai7XG1PqcsykQcywDthvJpChPnUAqnHcyvcWxxyxm1geWARQtQI7sXl2CYjDyzf7OqCq3jf49U3oka09461AGmj1ocH2OybpD5K64XfB6vEm4jgzo5buiEfA8QoOKIR+xlNwN0+CAfmqEwr1Y8ckpUMhBt4Fq68TJc8uATG8n/rITcGDGXA1Lkhmw7ibFpAGkAfOaGkbxyQl0+eBetxQRIwjF/nqa7POghcBECs4rgvC2tPtJ9VvO5CR62VYGC84JukXiDy8UUm9FnOZvN9MGH7mIw2M1/iIXvqBBah9/dM44yjY76egqZKNfkrABmFyfQ/enhCOKR60jTQi1G0gIdlN7JmtgBjeT400yym4q4QrlZhRj1GsOW23Vx8IZCKTAlCIBhAAp/KtJ+BmxxTlnqQFihV+M9LtdEuOCInhkx1mJeBiJVUtYy1dmY2Ao/GXzSNlSiIyMZWEJERBpmRKd4L2zgfgPx0rLF54AuVCYiKgAQGhB5SbWT5ozekHdhemgag3uwg4fCzD8DQ8AwG7L2shI5mIRkqUIAXREJPr5XI8zQXHlIDyKfQnDhR/h1ZHX2smZ/GU4chGJeZsyzCBOuoNL8tXMLbmbO6uJC1LaY6Ehkjkhr4QGcVESprmOBEXm9u0Bfutd256V+Ih96GcP7wxCaJuX2LuTmvO/kQc5uR/dzkitmQrowsi6BFqGetFqRo0ZhEBbyHdSDqTZBpNAgSBSEhZOFcsnonLrHuesYNyMf1WwIB0pvuD+Ap/st+a8/0D34liqI8ZZcHjoFTSqYvSpDE5MZKUkqw180s30rwP3y9lSiElIkiJUtCgEJM+8oM1HuaM0ZfQWc/c0N+b8h1IdfQzPCVfzdKX+KGwNqzyKyoS0qyTkPHA9FtIQS4o5J45jLokj609N96iPfHT5O+lyVKQEwUp0QalEBmBhrCFpW9xg3/H9dY1/ROJc4cTDyj1ZzfS3GomjBPJMLneCGYm3xPCUmBqCu6RyD1NT4vU0wajjjZIyZqz7+Qlxy9/Rso3iO40elKLnmiJQpPRolACmWieKo2/Fn9lvXLZA+5B9wtAgMMnIg7gM1y1y0w4KQ1Mt1WDPMskpA+KSSMVYNTT9pPIF5PrMcnsjgdM469o5i8jnSaj9GiJ+nSpTEHKsFnE09a1gOLHKaetUsBbKO/m9M5MWK7lg+Hvx5djRknIUlBC0wFtz6jQFEY9uaMtNGNSIfdJU5JZcMAV7tF/UEoPp91GQ5kjjYlR/SaEaIkg8gMVzzfuX4x91gufvzTxI99I/Bx9Ld/hZPwMt7/dzDgOUYtXSQcNEtLMBOylCKMeE/lGhXZMM6YJUtD05CAjzI7UvUPje6Vum2hpOmJERilEQUMKCkog0zQ/aS5/3scueRXCuuCHziY9i/5sYhWLAaC8ix1LZkdCteLc8HQsm42A+WAY9cwXck9TaCdRL8ekIaFFIwuzY59PON47iXsxJsboUWhaYo4oRJCD6NEiThbNr/tfD74CH3O0+eD9zyJ+lfhfh5evjopuorzKTGkzkAcEy9PRb4ZT8Gipt2kcmn6SaAQ5SMhTrTG5lnSSWRGW8UqNXwABY1KPEQXRokz6BkFEEum+YvwrlvMv4wpHl5+l/36MMCTc0PU/4RYzJdKhI15GnhZvxgJu39/LitZUpKt+AFokJJCMzJY7fM5J/lryYwAULKEnMjYREwlToSD6OdF+u1Fzb73v8P7Lv4ziiPINx7PwHMa/Mlx3g6KGQPo45S/NnNyQh954VBI2UGaTBc/ppSnhagnrSJglRTJrWn8peRzOAwUJOqDAGCNiRELKRFD6B8ijV3rivX5bGb8Pi2bNu+854qwziF+ifPfq1tIFIPaT/4buajNnLqOWDhmpatD0s6kDNopGqabaQ7eERntEBEw+qfEKyQuwAMIUy0SHnuiJQEtpaDIRj1Gav9DO/4kyfiV2myXbT/9O4+6nLHmEkuZXt5wpAN5LeS3pgJmTUi0goBYSzQyn4EYnC83AlNtM9RnJSJLNmjstOdWb9b4WT4BaQgplmdRROmKOPE80RMqaOEuJZ2rai/XxvJm8M/7cOSfSfr+2e7rkTFkyTiyvZiVxIF2DV/Lmmx0RvndUvemokpGmFrDMJgJmi0Z6DXIlW1MnRMgWJK0jwa0ut9MLzNumuJh61TqaIHpyj2WMKS0WJiK2p4j2u6TR10heL+JfLHZf4Oxd6KyWd787Of2RO21fuJel9I02lR9nfLJRok+M0SCjS/SIertpjTH5hXgDX+fIECPS0HTLtBCgHa9SwNaKWNBRTcGVfJWAc8iOFLu924leqvEPQguo65EUKMQyuSeCmEPQF3K/XTQ/rG+fYvPcx6Qb3qRvvqhbvMa5O2/A2BCv/ETyqEedYpxOcNGj7qNrL9b7OnNxgVIokMiJhAajxBiLiR59N7zOTnor7/hrR5TvGZEcfitsRoPoZrMpKes0QlMnHBwyOUkWJAuOJP/mVX7Ak/BjQh4+YQx6So+eWCbmaEaUEdHQ9KeK5puV0ddq+2u07TV27b9aP7pSTnt16aDIYyU1+rSgNNs86mHH099XTidr8rlSt02TspLoEwWRgJQm8iElErpgKdMHoea/6H+HxxVHlNSQTFE9c6kEaLqZRMCJgH2VaNQCkqYiYNjsSPJUxdjvWdAKP8Jhvv8lIfVTb046SiLK5F5DLnMin68058vRyQ6KtCw3HRFI5EZjTmdOlAUyqRAT8QIyGWlyDyJNP0MzTuTCGEuIBPBF2hey+9OOPJtMU0/Bcp2QjGdUiLYsK3XCUUsoIaExwiZHmn2+YovfAHynbIsY2F8NPXKgI3piTLSUeZNnQ7T0LaFV2m1kcksgZ5O9JzQNXSISgT6TEyUBMn2iR5PoJn2LLjEXLCVGGE3uHfTf+DW6j7DJkSe2oYo4qml30oyQlmazILWxLCkydSJCPR0jazDvaHCL693T8805iJ9B0iCGv4wIlKD06Mn9RMRJ/VBHNKRAJhUik1BaSiYK8kRApMl1n0goicgkpEwO+kyXaJAQiRbAZyx4Pj7iaLGYN5OQB9YApvovfnE2WXA7EXB6uq2lqxsLjha7XeUeftOcLfgezLGS3Y2AMomIZZItx4hoiYls0VAaSqb0yJOIlymJkkmJSKRJK4k86ROTMSmRUSbXPaT/Iv2+kfc4Wtx+1ibSdhIMFYCrZ8K8PKs64KKkG5Stvt+AOUeT3W53gt/U+KLsGcLxSv1dNkNf+ghB6smFGBMN/Yg8R8nkZhIh00S4TExE7Cdy9ZmUJtdpWk76oM8wERTyIt4jNb/qlP5SR5Pb2wUsEEgDG9PriDR30CpoV+xI2K2xrKmKz81gHRAWHG1udy1+2+k+KjxbeDzmFUAMtAYFEEEEpdCMKYvE3ETIhhhREhq6TGpIk3GbpoWkoCRSppnKjrtUhF2a/Dxf/NzfobjKUeZ+C2hJpptagukoqCzO5pT8ZI9kXEW6OvFQfb7VeuFG/+4UXxaeK3mi7EzB8D7vKQlLvfemYJFIpBHRURoiEy0pkZvJvYSJkGUiXMoIIgHZPpp369K/GvX/5KL7Wxd8cmkL80N7QAZqgXOLs4mA2V6NcZ35Dj8SgO3WEze50vF+zoKnCD8gfJ2wRUGqIl8ACsPfTBHkZcoypaEk8iQalnZyryHlqc8nEuZMZLJ36/MbpMVXO+uam6wnPnnxNkotHKA5ZMQhbptNIXqrg3qdNCBfQqbKkndYb9zpoLO8w6JLJG+U/YrGA8SAdAlNdQhXqc/hRN+TEP1Eskxu6FpSQz9PDpMISO96pXmNfv5PjZevwUG7Tre+KDum/2JRC3eotyE3zCYLXnankT1VtKt+EKraIPe3HtllGVfgCsd5gzmPl30bHoLzhG1CEuiRBs7krCNnTO3fz4XSkZcoLXm8JNxA8xmpfZPF/o24Td7LZuuU/hRaRCVa/TzYTo3jptlEwHe9bL9vfNZV1TvfYfkykrOsd/baj7c6xTv17oNvFx4iOUdxkuQkIUnIdeRDqqboyViPZK/karpb6D6jaz5g1L8D+8w7FrjvlFiH2QvSIHeUO2eThEDj2mqarWWsxTzZvHvgduud3Tpc6mU+7/l24ky9E4w8WHGG5FzFCXonY4dksyTphGJZuBO3GbtZcp3kK8a+LFwh3OgG19F3jinSvYk6+YCB/cB5F6ffsUoBz7Rikptq+WoB6xUxevfFBx0rPF3g9kmj8X47bNPZppg3sklnq2y70KBoHTC2W7Zo3kFL9tlvr/McRAH3dmzxvG88HtVDaRp46A9kpGu4oV+lgDdYMdlH6ihXPwNq6+K4x+GDjl0O2uMgbgZLaihoALAwaXscw8xfhFPISAPymRKgRXMZzCYJgd6VRjpZO7Ai5lDtYbZYwKINjiGai4idBAKQDvPdfPFZmE0SAm/4ozt9/y/eIDtjuPxSPx+6t0X3w6dscGzwe1+/ExeTjqsEA0BSRcclRl9avYBGVkX2CdkZlWhDWTDZ8bJHHksCbrD1NJxP5HqaIwHUUfFa4tbZRkDI3i77Jo2sGYx6JJNrJ8qegtfgZhusb5730BHjR9Hed7qmRD7MUvzyPtrrYTYrogFan5bdJDtl+L1wHR09WHL/Y0HADU45C1+H+eFDMVPdOvLHOXjn6gV00KrYZJex92t8Zx35BiNidqbk62Wfwm4brGPKwylPBNJKN8tfQ3wOS6sXcLXc5FYneLfsWzXaQ0XBQ2TGWfYdslfhYzZYx6SfIW8dPp63PhEVfIX5y6weLfNWxatfsexpP/1pXC67UFtJV19ntEjOxkslX42DNlhfPGs+85gfJx5Nj4wGgQDkQ61Nu4PmnSzdavVoWbJqGpcLl0kuQJKQVrBTrvEY2dfhtTZYZzzqYtqfhuHzanq09TfVX4P/Apj9FAwv/8PbPetpb9F6rMZJh5x6m4FpufG7sr14lw3WBz/9xPNIz6VcMPxVEACpkjN/gNs/dzcEvN1dInmb7CekWsDhpkFyjuTXzbkNn7DB0eVHnngy3S/QPJk8kPnWfQAKuj9noXMXySy4S+2lv3er7PclRR54H9xUPTRajccp/kj4GsFGO0rtFy48yejAHxDPIKbkA+gBkOpr5DfQf47eXW0tvbvMnLcrLpE9UKIWsX4WZPozj5S9VNiFSxxZNnjOheebm/t5Ed+lFPo8fCi6glLddz3jV7ibpPA8d4vnPe+7ZK/QOE5T1wLRHLZE8ynJy23yBuy1wWx5wUUjtx+8WJd/RTf3eEujHbqGgyO6FqNJm0Mz6UeYRzvpRz2jF9G+DLfC7JOQYd6t8Q+yXxwWbaAlZA/UeKGxBwkvwY02mA0vPjvZv+cnjfLPyc19pGh1iMQIfRCBqNaYRdV8gfKvPO+2NYiAa8Dvuw/+QOPJGo1m4OiQKjs+xPgmxcvxDsnVvsVuhA3uOg9Ic+6xcLKDm59kvPB9utGT9S3jecYtXctiO+lHLI3QYH6qn5uKjPNX0D4Db7YGpPAca8KLXvKtsj80cnq9YHWF2fH0GTSflbxR8kHh8/a7Bb0NVs4rHC8508HRRcrCN+vnHqOb22E8oowYz9G1jBu6EYtzLDfsn0eekm5uqrUYvRDPNcysC9EDHPBW222S/ZNUZ8ArOFMQMrI5ycWSB0luknzeTp+aLAO7zC0uq2XcAL8qe7CTLblIcn+Ni3XO1XT3Y3mzQGppglToe3LDKJGCvkdmuafLRKm+kLxD8zqal1lDUniGNeMV/3uzsb/S+J7B9YFtdZ0MrvqetJDtx63Yq3EZdglflFxv5EadfTbZZ9GiHQ643RI6a0UjORz7HI7hx/Ul7AcsT9qWSX8AT5C8yYJiXmezYrODtuM4vVONnas4z9g5xk5V3FNvm142Rsl0mxlvopunTKbcbp5uxHgSCccjDoxYHtGNMJqOfJ+geQbev8YC/tgah/6/Pl7xbK2f1th5yKRkZHJ9uL66hjS8OUvSC8uS/diL/RN5x4pO0gnLsl4RKCiSgkAIAQJQBIACQqkqFNBD9U8rU+OCTlIkk15IOo3epNfqjPSTVsxZtl1nm85WvTmdkQ5jdOgnrTC5T48OBcuIxHiefp7lzZSWfo7xHOMR/YguT8YtB0YszhMjjJZp3kf78/iCNaZl2Zry0z9wq7/+xz/Vu4fkB2WbpgXSACDVAtUSDok2eL+RbJJsEo6XAJBhYBxqSIhqL3Cu+vqfU6rPUr1/p+pLFfXrxLPUfxZT9+oEtT65ISOQEEHuJ30hCqmQe9pMZHKiKfQYoevpEpHfTXoBy18wA5rnuS/6tW1vvGCPb7r001rLssfK1eaple0nGfgqsvrXDoibhzbyV2OHuVb9Mw0cEqAaD/0AlcEvHq/GU00luWm5phoUpKHPE9FSEjEiT+RLiciYjFOmz6T0AX1+Fv3H6M2itSybCT/5Lbu84g1/YKvjZD8jaWVAMtys4p76eqoF6s+h/jxXf2n1rxtaDFzLkRGVeHVUSmiq6FpgIPJNmrb69dDXP5T1hrXqB7gUdKSgDXT0GUhIQQ6aQilhLv7DUnqhhfGnzZAUC19vprzorfNO8lTZL8keKlsYPl1/OIoMnRA7LOXgtDp8LwAO9y35A/cC9cFFZar11XWPbqovU/0YPZaZ3J+Mq8/HKFhGX///qnvjhrIwef5bYJKE6OfoJ4nHuPmCfuFvHPAK3GnGpDju8Y4If/nui7V+UfLtki1TEq5MwPoahjdqrZZhAROiaqpxLWUcRryYEqNDUcs4fD1GX40nvVJ93mM89Vk/STTKiH7LRL55xv9Pv2zcXGLc/J5rPvo69MyeFI4gr3NPje/S+DHZQySN5lDPcQNjh5u6hyQcmlprKukMSjcsYR0J+1UK2A3IOK7v121KuB4F40rAwPKIfoGyQDeiW6Af7TKe/1vj5m34kCNIivMf4ojyG59acLIHCN8t+wHZSZoBqepkhGEpwYCIUY9XEQUZFhAKYiXT8ICM40rIMeopNyZ9merHA5Gy/mcsI6Y/z5RN9JvoR2F54dW60d8po/e69NL9iCMroKPI22y3yc/qfbXs3rKTZK00FAWrxnCvygZV1xCwwnEMjAtU4qkiYKnFq6fdKmr1dUQbeCbsUI/rX9erx7fq5m5W5t9mPP+v+ISjSIqHH++o8uFbk/9yJp6o8RjJIzROk2yXhhOSgRpfLd4AqxDycBGxwGGm4BiKgJU0dTG5FqnDUvVrp5KPQXE7S4qr9a6w5D/wHjf7LJYdZVLc3/rheTY51X1wgeSrJs+JD5bskKRVZb9phVmwVdwrqBMTA5GvAOpMuKvGQ+L0hrPeOtKN1fKGzgG9qy15r3ApPmXRNbjWOiLFU60/fk2rsdOc4ySn4GxcqHFv2b1wFrbIsAIJoxJwSMSEAitIRADq+329kLiOgPUUXD+jUQs5uQ7Tny+bFrbTu87Y1RZ9QXKpzuUW3WLO9Tp3YNk6JMV3Ora4QPY9ttjteK1tGmfKTsAWybx+0mfzipF20tNKWiEjS7IyuSbJCAmUybhM3WO4LggqAXskoUcPQqATOhShCJ0i9DpFr1jS6U2asbFFnWWdJWOLegd1Dhq7TXGj3k16d9hlN3orZ0PADTbI/v/KBhsCbrDBhoAbbAi4wQYbAm6wIeAGG2wIuMGGgBtssCHgBhsCbrDB/wlKajuIhIz6AQAAAABJRU5ErkJggg==', width=50, height=50,image_fit=ft.ImageFit.CONTAIN, bgcolor=ft.colors.WHITE, border_radius=ft.border_radius.all(20), border=ft.BorderSide(0.2, ft.colors.BLACK45),
                                                       shadow=BoxShadow(1,10, ft.colors.BLACK45, None, ShadowBlurStyle.NORMAL)),
                                          ], alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER)
                                          
                                     ], run_spacing=15, spacing=15, width=200, height=500, alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER))
                       ],padding=0,scroll=True


                       )  
    def RecoverPg():
        
        
                                           
        return ft.View(route='/Recover',
                       controls=[
                           Image(src='https://media.discordapp.net/attachments/1114428377613467669/1142586446268600350/blue.png?width=883&height=497', width=2540, fit=ImageFit.FIT_WIDTH,),
                           
                           
                           Container(height=700, border_radius=ft.border_radius.only(20, 20, 0,0), width=2540, gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=90), offset=ft.Offset(x=0,y=-0.025),
                                     shadow=ft.BoxShadow(2,5,ft.colors.PINK_200, None, ft.ShadowBlurStyle.NORMAL),
                                     content=ft.ResponsiveRow([
                                          Text(size=40, text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Recover Account",
                                                TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.PINK_300, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
                                          
                                          Text('Dont Have A Account?  ',size=15, text_align=TextAlign.CENTER, width=500, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Create Account",
                                                TextStyle(color=ft.colors.BLUE_500, decoration=TextDecoration.UNDERLINE),on_click=lambda e: page.go('/register'))]),
                                          
                                        
                                          TextField(value=f'',label='Email', label_style=TextStyle(color=ft.colors.WHITE), border_radius=15, border_color=ft.colors.PINK_300, col={'xs': 12, 'sm': 8, 'md': 10, 'lg': 8, 'xl': 4}, scale=0.9, password=True, can_reveal_password=True,
                                                               text_style=ft.TextStyle(color=ft.colors.PINK_300), on_change=RecoverCheck),
                                          
                    
                                          TextField(value=f'',label='New Password', label_style=TextStyle(color=ft.colors.WHITE), border_radius=15, border_color=ft.colors.PINK_300, col={'xs': 12, 'sm': 8, 'md': 10, 'lg': 8, 'xl': 4}, scale=0.9, password=True, can_reveal_password=True,
                                                               text_style=ft.TextStyle(color=ft.colors.PINK_300), on_change=RecoverCheck),
                                          TextButton("Confirm", style=ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.PINK_300}, color={
                                                               ft.MaterialState.DEFAULT: ft.colors.WHITE}, shape=ft.RoundedRectangleBorder(radius=5)), col={'xs': 5.5, 'sm': 5.5, 'md': 8, 'lg': 8, 'xl': 8}, scale=0.8, height=50, on_click=RecoverSubmit),
                                           
                                     ], run_spacing=15, spacing=15, width=200, height=500, alignment=ft.MainAxisAlignment.CENTER, vertical_alignment=ft.CrossAxisAlignment.CENTER))
                       ],
                       padding=0,scroll=True


                       )
    def RegisterPg():
        return View(route='/register',
                       bgcolor='#ffffff',
                       padding=0, controls=[
                             
                           ResponsiveRow(
                               controls=[
                                   Container(expand=True, gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=90), height=90, padding=0,shadow=ft.BoxShadow(2, 10, color=ft.colors.PINK_300, blur_style=ft.ShadowBlurStyle.NORMAL),
                                             content=ft.Column(
                                       [
                                           
                           
                                           Row(
                                               [
                                                   Container(expand=True, height=75, padding=0, bgcolor='#ff96fa', border_radius=border_radius.BorderRadius(0, 0, 15, 15), shadow=ft.BoxShadow(2, 10, color=ft.colors.PINK_300, blur_style=ft.ShadowBlurStyle.NORMAL),
                                                             content=ft.Stack(

                                                       offset=ft.Offset(x=0, y=+0.3), controls=[
                                                           ft.Row(
                                                               [
                                                                   Image(src='https://media.discordapp.net/attachments/1114428377613467669/1137269328836821033/IMG-20230731-WA0000-removebg-preview.png',
                                                                         offset=ft.Offset(x=0, y=-0.3)),
                                                                   Text("Blues Lavish Braids", expand=0.8, size=15, weight=ft.FontWeight.BOLD, color=ft.colors.WHITE, offset=ft.Offset(
                                                                       x=0, y=-1)),
                                                                   
                                                                   
                                                               ],
                                                               alignment=ft.MainAxisAlignment.START
                                                           ),
                                                           
                                                        
                                                       ]
                                                   )

                                                   )  

                                               ],
                                               Container(expand=2, gradient=ft.LinearGradient(
                                                   colors=['#ffb4fe', '#fbe5fe'], rotation=90), height=1000, padding=0),
                                               
                                               

                                           ),
                                           
                                       ]
                                   )),
                                    Image(src='https://media.discordapp.net/attachments/1114428377613467669/1142586446268600350/blue.png?width=883&height=497', width=2540, fit=ImageFit.FIT_HEIGHT),
                                   ResponsiveRow(
                                       alignment=ft.alignment.center,offset=Offset(x=0, y=0.05),
                                       controls=[

                                           Container(gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=90), height=900, padding=0, width=100,offset=Offset(x=0,y=-0.07),
                                                     border_radius=ft.border_radius.all(20), shadow=ft.BoxShadow(2, 10, color=ft.colors.PINK_300, blur_style=ft.ShadowBlurStyle.NORMAL),
                                                     content=ft.Column(
                                                         scroll=ft.ScrollMode.ADAPTIVE,auto_scroll=True,
                                               alignment=ft.MainAxisAlignment.CENTER,
                                               horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                               width=500, controls=[
                                                       Text(size=35, text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Create Account",
                                                        TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.PINK_300, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
                                                       
                                                        Text('Already Have A Account?  ',size=15, text_align=TextAlign.CENTER, width=500, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Login",
                                                                TextStyle(color=ft.colors.BLUE_500, decoration=TextDecoration.UNDERLINE),on_click=lambda e: page.go('/login'))]),
                                          
                                                   ResponsiveRow(

                                                       width=500,
                                                       controls=[
                                                           # TextField
                                                           TextField(
                                                               label='Name',value=f'{ClientInfo["Name"]}', on_submit=Check, border_radius=15, border_color=ft.colors.PINK_300, col=6, scale=0.8, width=150
                                                               ,label_style=TextStyle(color=ft.colors.PINK_400)),
                                                           # TextField
                                                           TextField(
                                                               label='Number', on_submit=Check, border_radius=15, border_color=ft.colors.PINK_300, col=6, scale=0.8, width=150, prefix_text='+27'
                                                               ,label_style=TextStyle(color=ft.colors.PINK_400),keyboard_type=KeyboardType.NUMBER),
                                                       ],
                                                       alignment=ft.MainAxisAlignment.END,
                                                       vertical_alignment=ft.CrossAxisAlignment.CENTER
                                                   ),
                                                   Column(
                                                       alignment=ft.MainAxisAlignment.END,
                                                       horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                       width=500,

                                                       controls=[
                                                           # TextField
                                                           TextField(
                                                               label='Email',value=f'{ClientInfo["Email"]}', on_submit=Check, border_radius=15, border_color=ft.colors.PINK_300, col=2, scale=0.9, suffix_text='@gmail.com', label_style=TextStyle(color=ft.colors.PINK_400)),
                                                           # TextField
                                                           TextField(
                                                               label='Password', on_submit=Check, border_radius=15, border_color=ft.colors.PINK_300, col=2, scale=0.9, label_style=TextStyle(color=ft.colors.PINK_400)),
                                                           TextField(label='Confirm Password', on_submit=Check, border_radius=15,
                                                                     border_color=ft.colors.PINK_300, col=2, scale=0.9, label_style=TextStyle(color=ft.colors.PINK_400)),  # TextField
                                                           TextButton("Create Account", style=ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.PINK_300}, color={
                                                               ft.MaterialState.DEFAULT: ft.colors.WHITE}, shape=ft.RoundedRectangleBorder(radius=5)), col=2, scale=0.8, height=50, on_click=CreateAcc),
                                                           
            
                                                           
                                                           Divider(color=ft.colors.WHITE, opacity=0.5),
                                          
                                                           Text(size=18,text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, offset=ft.Offset(x=0, y=-1.55), color=ft.colors.WHITE, spans=[ft.TextSpan("Other Options",
                                                                 TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.BLACK26, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
                                          
                                                           Row(

                                                               alignment=ft.MainAxisAlignment.CENTER,
                                                               vertical_alignment=ft.CrossAxisAlignment.CENTER,
                                                               width=1000,
                                                         
                                                               controls=[
                                                                   Container(image_src='https://media.discordapp.net/attachments/1114428377613467669/1142616052182823033/kisspng-google-logo-5b02bbe1d5c6e0.2384399715269058258756.jpg?width=593&height=593', width=50, height=50,image_fit=ft.ImageFit.CONTAIN, bgcolor=ft.colors.WHITE, border_radius=ft.border_radius.all(20), border=ft.BorderSide(0.2, ft.colors.BLACK45),
                                                                               shadow=BoxShadow(1,10, ft.colors.BLACK45, None, ShadowBlurStyle.NORMAL)), 
                                                                   Container(image_src='https://www.facebook.com/images/fb_icon_325x325.png', width=50, height=50,image_fit=ft.ImageFit.SCALE_DOWN, bgcolor='#4267B2', border_radius=ft.border_radius.all(20), border=ft.BorderSide(0.2, ft.colors.BLACK45),
                                                                               shadow=BoxShadow(1,10, ft.colors.BLACK45, None, ShadowBlurStyle.NORMAL)),
                                                                   Container(image_src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAYAAACLz2ctAAAtXklEQVR4AezBAQ0AAAjAoNu/tDl0QAAAAAAAAG9NRy179gDrX9NdcfyzZ8793b9r27Zt2wqqoHYb1rYdt1Hj1AhqI6jdPrafizO7uHOSnfMi+uvFTlZm73XO9TdrZnK/TB6/Ctef5jqudm4MbgTXBofGUXAYHJaLvq/GUee4GR2tGz2tndaa80a2hWhAdCPCiAA0dBmBBQ1bH4BONqFJi8ggm6FrGWRnXKwxmrHS1kWsYYyDOBucdLk27Sycnod2cixOhzw7Fs8NnljFk8PZ01fFs087fRzPegmt+HP3uNvrF7325eD1lu6t1/SW2bxWX71x8iqRDskRjoNlqk9FoyW9yUjZQvYwgmxdIqMRzRoNNuiEjmYIIqQmNQQaltJvft/gFLnNDX3OIbLJ7FKIPBIjZAbTjzUYTeairawjGOToYm2chHG6cIa1y8eSe7r492Y8EM7/7Ez7rzf1mg8j3eUVKd1N9ZVXvUY786qteUfpnYKPkN5QuhaJokgCEEUNCbM34QlDQxhCCpu/gjb9xtTQUOHr6ucMCzbfXKN4Md+pMIbQ6rtzbnLO1Ln21QspdjPDBaT53138NeN3mvO/Pji+7xW95n04eTmAu/o8Lr3qVW++nnmj1ny08B6R3ly6DJEYhLnu4bPv9zCOCVAW+NjgaxID6QghN1AnHEOvMBTgluLt4eo28KI+n37Od7MAOHQNSQGvzb4CGGWtgDLUPlg79zTrn5G/162//4z1P/Cwu6DiHv/gTtYPXXnzj8nwYdL7S6/b0qtFIIkJm6TC15JaHQqE6h+spF2Xcs6b39VkTItkex/toi/gbT52oDW0CZitl5svsGy9nE5qWMQOMKImq6SAW1O5wvjCNbbPfTqs/975S/JXbzj/VTxyhxPw79yJ+porb/lOwee15qMNryNdikQWgCaEkpizCWAgC2hKH1BTrEC1zNSLDawCYNsDKAuYUYBlQYgKjIOgAlfTUmyfRxdy9il1sYdOg33i1c+/B466Fo0pQnIxn+L+kP/cjB++4t9+Eyd3CMBfdbvqy33U8ZVr3uucL4z0icHV2GCaYBlAywLclKyAAYGOKGogS/LVs9+qTfBM4FqBsU3IzHWhwBuipGDIOdNFScU9gAG7rbSeA4HYVAGsniFEAW0gNCkk068/nwmhzZt92a7PG3966vQHw8kf4H63seJpf+p21Ld4t9d03cdKXxe8uQRiEGqylXMeYi3PVQBfeGLsz0nNqtU0nOnX59z3aWctZ7cJZwGws9/6LKKAVS8eKbQdTKFJrSTh5sf0a5rZIBUlybBPPpA7GPdKrAIqjFKzPtT4le78m/EftzEB/9KtrPBO8Q3XvLX0tcJH49UlMWjq9nohaGP6VfUP/GLUqYmmGxiaUdJt1LSbIG694pkfF/UWLMo2u78Zd20DYoNM7OA0e+X2awO39HsQ61wvUknxxsTa7JXkI6zswdxAtEr5W+SPd9d/43ZsywvX3cr62uveE98ZvLdwsMHUaImYwAUxoIJHY5cEBKAVlWQoyTV0Y65ZUs0GqAWBmLAu5VmBtMC9hzxmHxobQOy2zQ3YCiepUdIaCPbPZIFYgc8ujbMmIxW0zdGo6VfW0OQH4fV48rVYfgHP3OIE/Bu3or7a218+vuGTpZ8P84JRoAJoFbpBjN35zy79CgTFL/2oAAprmdOypSETsGGRYurIoKRdLynSRAVYF0xvQlWSDxtYWgEidhenALETkPXzU8BUkpDcz4LiZz0DCuaawpBztUlOnf8SR1+Mh29hAp7dgvPeu1w5vILPaekbpEsRBCJQt9S5GrsLRdIrpFDhm4K2B3N3QyypNZUl8WYKTmjJAtiw1PcpICsA24ShFcBil3pRe+qtlro9S9if7+TuZ8MuxVRApdwl6/Y5kqKo0FH6+DTO/pHTn8F/3RIAb3bCfu+rvv/10xOfsaRvD149AogoIGUBcqWNDcjZ7858ClgNSt/ZATGmN0aT502eLPL5Lk/TOFt4Pi78sRgZcjTySGaTSbrw6bJAPdLs65bbNGFomkZJGtGY7wUiJkzRBTQyQosmG9nJQ4hLF2seB5dCLEFLIwJ250AAsgK+AwwGCLn1yJ0A9R3rVxOvyvrt+O9bAOBwM+uZUx/bYsKHTZIAtCAqaBt8Zd4lWvXOgoeDexb+Jbmn8dTCk8RzXTzfrKchnj/iJLVnunyuy/O0JrkGo4tMq8vkKZCLwBlIHEgO4OAUADFdDhKBVIuDI8Cp0zhsroMzZ3E014OG8yDi3HkPrR85tHB6vFquNC43ebxwPOQxcSXEFdZXaNorhnxL8nXxWuRlYBQIYZQ+i/aVRYGBuIxP4+ghjn4Yj7iJFelP3Kz6thvv/m5n/FGjB5Rz3P4/Gm0q7NOvbquexn0L/xn8Ef7mwJ/8J/dgeHkB+Cb/8uosb8r6/ng3vBnj1cnXICuMU1l6Zc6ptXjrXP0wH/h1OL/r/hf8Lde8re6HpA+NknaSmDJoCmQD6/RMKP+nvbsAsuS4En7/y6y63T2sscVMRsmklekz4zIzM++alzf8DIvGb3ntZd41My2ZmS1ZMglHjMPdfavyPLobcSNj6k231Hem50X/I9JZWdcjaWb+fbLOqcy8RMMefBIfSfxnw6dX/iC8wU+5fjMH70d5IL6HuBf9mUQzLeNEsqlWKumgn5a2p3sq/msNBXznGsj31BOb7EWJ74iwJcHUtBpBiinJpt9wFGIiZmY586+JdxY+cCs3YNkGdyMyfuJ4tj6A7htI3045qxKuuu6hjnwIdCifoPwsPrZGAr7d3eGnfc3o9O2+PfOX2JICpoUjBYFcJRmCpp+IyheDP5znjTu4Ab01YYPvJHHJiYzOZPnFlMfhUBJOtXock9YvEf9G+yzctgYC/oe7w28d96THN+HvU3FGSvifCAf/IyDERLhCiknrydyY+MfEi3GzmbLBz/jsFnwH/dOIB1JawnSjryJifd9BumfR/A2W3A3auzvDjXrflzgjBSYt+Z+ePB0Ro46Cbiv8Pv4y2GfmbPCnHrj/5/h7Pn496bnEo1FFvPj/aFA2kX6Cuffi80ctAr5k+5MeGsV7EpvS/0gGUMiTPiFNop9g8hy4C7/1U7wSYYOjwCfuS/+PlK869FQcA9lxZ3L9J/gFd4OWPe4qUfxEEzZJ1AJCE5QgIwc5kXqasBsvnecf/4GwwVHiqy7/QR/6Tfwu8WCmZQMD2XEgkL6XO5+Dxbsh4G6snpct/MgT5nhiQhRSIiEVpmUc1e96w0147k/wFwgbHGUe+Q4+fAfxvykPIzI9oAy0MOnvwfZn8u2/h7B6pLB6Xi3mbtrs5Sn5sQgLSbWkatKmi8uTscQf7eZXcNCas8Ezvbvl8QXFqnj3D5BeTjkeKAh0iCEBUT7M8ndil9Wj5R+tlju2uE/LIxULkKaXyBcgFUzX/oAvBr+zc83k2+BHvLvl+LPIj6C7F8edxqfvIK4gfwSfsiJueS0n3Jf4jfr57zDlmvNpvwZ/afVoaa2W1Dmn4XyJBIjpwnKaqgGaXBN4GW60hmxwwq9RvonxaaQt2ExZxh7KbYxfQ/c3uNowOO0gy39M/AJlx7CEdYISx1Eexc5/wNLqBbTdavhLX3vSiG+IsC0FEUAytZOtLsEg8erCW91tNvh+Ep+9AC8mvoaAaTFaYjNOJi6g+S76X2P5nVg0zI2MX0D8LjFHDwiUqkFB1+Iibn0wPrJ6Ad1qNcxxai4eHQGYFhASqQDQIrE38/pXcYM1YEPAz56G36U8GXWNDuoodT/S8xjdjvcxDPvfTvP9lItI9T8HtYSBOBfn88MfRaxSwB9cnYCNe0fvPEFKlCDXElKv5/vomA98G70N7hbf4/072fKDpKcQLQWgFqNuD6a8BA+HYfIV9K+iPIho6BEDq2QAbKW/iL99K+5cpYB/azXk/kceHswlCDIyYmB7IQ4kPnEJ11kDNthxOuMfJOZRiRCAGGpfRX4gPmuQrUvc8UnKtTi7WpwKCEBfCT4+EXfOdEn+HF8TyAAIqASckvLaxFsuplgDNlj8avL9KIgB6aD+HEpD+Wme8AsIg/zrpcxfQpxFn+hR/3N7FCT0iIfhFHxxdQKugjf7yc0tZ0NGVPIFciUjri9cYo3YoFwwLF2soJUL+MBW7DXI99zAqy8jPYV+nnoKdqhVMlspZ8HMIuAmzgo2FWRAqabfDIAEfBx3WCM2iJOGhTPdDxSO02b27MCwgN4epI8xvgWnD5dkahnLg/H3M9sTMuK+BRCVcBmBaRqM+Yg1ZINYImCVURCgD+bGDsuey4jbiNOHM2G15OfBzARsuH9jOPpFJR+6OAYFfLzntzxxJ8sn0J1EeybpfOJsnEyzhbSVmCN1OEDsJe0hfYX8JdI1uIXxjYx2Y681IT6PbyENyFeqe10lpi/x/lscnks478vEg6YEq/95VSJS7s0zE2IVAj7dSpnztJNV0tXPgYXpJOS2TexyjPBwb93JwoU88t4cfCjNA0kX0G8nIwH6gTO5AgkF+SBxC6P3Uz5N8wl8BVe7W5QPkfZQtquj23Ckmr73bi4qVsRtV2LgmY9DTM1n8+LN2L8KAV9sJVzqOXMjzquTj4I8rPzV1jkXeXXD9nPIT2busXQXEWeQNtNVUqmrnJWMaToz3EQ6k/77SN9FXE+5Fm+ifT+nfBKLVs1VHye/nfLdpAEpoK8kgbiNxTdaMeVSkuGl+lGPF0jHr1LAZCU0bJvjOFUZsq1ELEiA4ErrmAd59VZ2/CK+hTiP2EG0h87vA1DXAFLVZ6hp6c/EmaQL6Xex693EX+OTVset9K/Co4nTCBRAfV2P/THzt1gx+2+mQ1nhwoSCvMMqaAkrIbF9nvlUBfYetcKBhLQOp9/7+sSIvWcx/kG2/zDlLHowTKr6HpCqBqrPVJ+lHaQduAA/T7yS9FqWP4LdDk+H1+E4PJu4PzH0Cg4RlP3EbzP3Cqti6WYMRL4ykJAsn4nPrkLARSthM1sKTVRTboMYKEon9lhHnO9dW0jfhB+nfyxGFBh4omW41G7g84QwLKb6n/dTxBOZ/1PiDVY+a/w1i7dQXkicjy1EJYegfIzyRtJfs3yHVbG4l3mE4c3ttfjNCVZBS2MlNOxomB+uPEEoSAKhiH3WCed673l4GuPvxQnDZ6IEatJQZKtamRZw4CVlOdT4fMoL8D3EL+KjVkT7Zrov0T2O8hjiQspxpH3EV/BRvIM9l2LRqsn7h1ZEDz8P2rpKAXsrYYGtPaNAUSf+RZKEkIWEUIxYtA44zdvuw/yLiSdStgy/Sciokw1VRKsFrZ/7Sh3l6ux4oGgcW/Ew0h9R/pw7/gnLDs/luJodb2O8g36ebky5kxNuxz6Oc9f43BJ9ITKl2hNiYP/IeH4m2zLn2DoWIwghEDAZhYl4QhECSRxVAU/23/PEj9I8j+6kQz+k90iADlDLFnW0q8WqBE7V/TTV90iGSQ/Dg9j5ABb/DF9yeA6yfC2upUUL2OfusXSAdomyiVRHv4FIaPNM3gXPMUfJvZBMu19AL1Bk01OwJUeJk3xsK/13kX6H2AnUf4BQhkRAUlELWY3LgLihFnGYgHnS02jPIn4GtzgqfHSRh+8nNlWSGX43bG4mWXCxON9KuQGhTPUhZFAUoUGIEuKoCHgP795G87P0v0jsJAB1/m4Vz3x1qyVMA2MwICTDlAbfRtxG8zu4yhHnx3ou2Uscf4joNzSen8kzYKOMktQEQkgC5CkZCWXSB306CgJu8x9zLHwt/a9jO/3AEWSqWt40xbBYeXjZxWDtMCE5PAG1sN9Hl7jjN3CzI07spx8Qrr6H1QtYrISRMhfkiWAaTK6r/y0ClOVes98RJ/8Y49+nbAf6SQMoA283IEE9bRbSftxOvpP+StIdxD7yMrnFZspO0imkE0nbsRNzwyWbmgQOURbagh9nxyLxu7jeEWXXvrrkQgcDUs5IQEqbRGoUYCrpgDKRL5mMlMVWHHAEGXn3ReT/g7J9+Cd2qGqpyoZjiXQV5VLyJ3AJzRWcdDk6NW5pWLwnWy4gX0g8jHQf3B9bKMgwLKQ0VBpK+Bnsxm86opRu+NwYtXwo7YwEXG5JmQAUWSCEkGEiYRGwFEo5cvL99zmMns/4ZMrA0nGqzw6VTCzRf47mX0kfJ11G3Aws41oD9LiZ/Tfjv8nb2Xwy6VGUb8YT6LeTVjr9Vr2W8jTKu/BeR4wY061gCi6AaGeShNC15HyoZ6hUnbieBCwnpXdE+OI8fob+CRQUAHQoVXSpM9UMcID8+/SvYv+VPG0Z4a6xB3t4xZWc+F7KE/DTpItxuGRkoNRfthG/Oim5XOmI0HcUGBSvOnW1nUkSQpln3BAw8MK7TAlZlmh6M+e/R7TfTfMz9Fsoh4l41NMhcYD4N+LFuAxo8CfuPt2Y67+Cr+AvOen5xPeTziHl4cjHwL6Pp5Key95n4Q4zZ7w8sD1zoKRVmllNwQ0lkVBgOB0H/ZiDYeake1N+kNhen940vGgzoSDgKtp/Yv5Pcb2ZU36PuJz8y7iQaOsSDQWgvkY0eCJbH8kV70AxWwqljnrDPyCkGW1KGjeUVE+/hkschQgzp5s8X6kLowNLZ/O0iLfgl1l8G/Y7Itx+kP3/xoVfon8uvpEAVT+QFRc4k/gxzv4MrjNTLi8YXo5FNe5XGwG7VQgYiYCBkGw6AsXsBdw1R/l5+oYyvDFHqqMh3E7zq+x+PTpHlsIlH+fcp9OeiwtI9azCcFYMTyEeidcc6Qg4fNI+RJ5RErKcKYkY2nlVR6CgMzueknjRc2hOreUjBgrK0CHfSv+DvOs/0DlqvPtKfvTbGP0B/VORMTSj1AJsJ36bfW/FQTOjKwTDEa/+wUkzEnCpQaoLuZSBelBfEGbG755FfCNjFBiIFnVxOd1G/Cm3vIeHdI46n/4iD34p6QLSGQQMJFF1K/dm68PwHjMjKgHL4X5A0qySkEwkykAELNW9PujNjvSNjM+hh+FFAVQSegvNn3PPg9YNu9/H9j8g/QZlp2kUGK7DGf8wt70PxUzoAVBqCatmlknIUgJKbT76+g8HHZowEy7ZTHk45QTyQCG3ALIpxjQvoLvBuuL2JY77B7rH4RsBiBVUHOLBnHghPmsm3BlDq6AH9iWnGT8DFtONhA4JBWOAoJgN+x9CfhTy8JQbaNAjkArNCyhXWJd84WZOewZzT8BWyko3nd+Lpe9i9yUo1pjhVTAG6oBhRoXoA4mMfmhXPAJ9Jeda8+9znH0/ysmESRt4n9sBMspn8Vbrmmuu4Nx3EN+BoWhT/6VvpVzAju2405pzaxDqBkP3ZzUFO3QZpp/qTfXdjJ4Bd96T5YuJheHlVPXSqTQm/QP7v2Td0/8Z6bHEiYYjTl0YPoflc/Apa04fAMRK2sySkFS9dhvYoNyhwIyqA/M7WXooCeozuSohCxLSdbQfZmGfdU/+MuP3kL7zEAIOTXsnUE42E8LKBYQwqzIMukSYbnSgfg1GxGySkIMnEvcjIWD4iEyBHDSfYvFSxwQ7r+Pmd9B/AzYNr+yJ6Xunku7H1v/CkjUnqjZc9pphErI/kwY2KB9qDL0ZCHg67SYSDCyNzwBIeyZns+x2TPDfPff5Iul6nFdFuuEvmOZc9m1dewH7ICGqZrCf1btgBMpKzolDMRvKvRgPlJxyJWNG3IJPOaboryZfSTkPKCvIPMvkaBG3WXOGi8+kIzUFj4cPpdHX0/AMBezOJw1MtwW5zoj3E19yTLH3FrZeg57SAFG3eja6B2nBmhPD8lHdM8sIeBDQVxKODe8ZXbb2jE8CciVcroTMKChX849fdGyxyO9dTTpAbKMADEU/lJOIzdacWjrDEW+2Ai7XG1PqcsykQcywDthvJpChPnUAqnHcyvcWxxyxm1geWARQtQI7sXl2CYjDyzf7OqCq3jf49U3oka09461AGmj1ocH2OybpD5K64XfB6vEm4jgzo5buiEfA8QoOKIR+xlNwN0+CAfmqEwr1Y8ckpUMhBt4Fq68TJc8uATG8n/rITcGDGXA1Lkhmw7ibFpAGkAfOaGkbxyQl0+eBetxQRIwjF/nqa7POghcBECs4rgvC2tPtJ9VvO5CR62VYGC84JukXiDy8UUm9FnOZvN9MGH7mIw2M1/iIXvqBBah9/dM44yjY76egqZKNfkrABmFyfQ/enhCOKR60jTQi1G0gIdlN7JmtgBjeT400yym4q4QrlZhRj1GsOW23Vx8IZCKTAlCIBhAAp/KtJ+BmxxTlnqQFihV+M9LtdEuOCInhkx1mJeBiJVUtYy1dmY2Ao/GXzSNlSiIyMZWEJERBpmRKd4L2zgfgPx0rLF54AuVCYiKgAQGhB5SbWT5ozekHdhemgag3uwg4fCzD8DQ8AwG7L2shI5mIRkqUIAXREJPr5XI8zQXHlIDyKfQnDhR/h1ZHX2smZ/GU4chGJeZsyzCBOuoNL8tXMLbmbO6uJC1LaY6Ehkjkhr4QGcVESprmOBEXm9u0Bfutd256V+Ih96GcP7wxCaJuX2LuTmvO/kQc5uR/dzkitmQrowsi6BFqGetFqRo0ZhEBbyHdSDqTZBpNAgSBSEhZOFcsnonLrHuesYNyMf1WwIB0pvuD+Ap/st+a8/0D34liqI8ZZcHjoFTSqYvSpDE5MZKUkqw180s30rwP3y9lSiElIkiJUtCgEJM+8oM1HuaM0ZfQWc/c0N+b8h1IdfQzPCVfzdKX+KGwNqzyKyoS0qyTkPHA9FtIQS4o5J45jLokj609N96iPfHT5O+lyVKQEwUp0QalEBmBhrCFpW9xg3/H9dY1/ROJc4cTDyj1ZzfS3GomjBPJMLneCGYm3xPCUmBqCu6RyD1NT4vU0wajjjZIyZqz7+Qlxy9/Rso3iO40elKLnmiJQpPRolACmWieKo2/Fn9lvXLZA+5B9wtAgMMnIg7gM1y1y0w4KQ1Mt1WDPMskpA+KSSMVYNTT9pPIF5PrMcnsjgdM469o5i8jnSaj9GiJ+nSpTEHKsFnE09a1gOLHKaetUsBbKO/m9M5MWK7lg+Hvx5djRknIUlBC0wFtz6jQFEY9uaMtNGNSIfdJU5JZcMAV7tF/UEoPp91GQ5kjjYlR/SaEaIkg8gMVzzfuX4x91gufvzTxI99I/Bx9Ld/hZPwMt7/dzDgOUYtXSQcNEtLMBOylCKMeE/lGhXZMM6YJUtD05CAjzI7UvUPje6Vum2hpOmJERilEQUMKCkog0zQ/aS5/3scueRXCuuCHziY9i/5sYhWLAaC8ix1LZkdCteLc8HQsm42A+WAY9cwXck9TaCdRL8ekIaFFIwuzY59PON47iXsxJsboUWhaYo4oRJCD6NEiThbNr/tfD74CH3O0+eD9zyJ+lfhfh5evjopuorzKTGkzkAcEy9PRb4ZT8Gipt2kcmn6SaAQ5SMhTrTG5lnSSWRGW8UqNXwABY1KPEQXRokz6BkFEEum+YvwrlvMv4wpHl5+l/36MMCTc0PU/4RYzJdKhI15GnhZvxgJu39/LitZUpKt+AFokJJCMzJY7fM5J/lryYwAULKEnMjYREwlToSD6OdF+u1Fzb73v8P7Lv4ziiPINx7PwHMa/Mlx3g6KGQPo45S/NnNyQh954VBI2UGaTBc/ppSnhagnrSJglRTJrWn8peRzOAwUJOqDAGCNiRELKRFD6B8ijV3rivX5bGb8Pi2bNu+854qwziF+ifPfq1tIFIPaT/4buajNnLqOWDhmpatD0s6kDNopGqabaQ7eERntEBEw+qfEKyQuwAMIUy0SHnuiJQEtpaDIRj1Gav9DO/4kyfiV2myXbT/9O4+6nLHmEkuZXt5wpAN5LeS3pgJmTUi0goBYSzQyn4EYnC83AlNtM9RnJSJLNmjstOdWb9b4WT4BaQgplmdRROmKOPE80RMqaOEuJZ2rai/XxvJm8M/7cOSfSfr+2e7rkTFkyTiyvZiVxIF2DV/Lmmx0RvndUvemokpGmFrDMJgJmi0Z6DXIlW1MnRMgWJK0jwa0ut9MLzNumuJh61TqaIHpyj2WMKS0WJiK2p4j2u6TR10heL+JfLHZf4Oxd6KyWd787Of2RO21fuJel9I02lR9nfLJRok+M0SCjS/SIertpjTH5hXgDX+fIECPS0HTLtBCgHa9SwNaKWNBRTcGVfJWAc8iOFLu924leqvEPQguo65EUKMQyuSeCmEPQF3K/XTQ/rG+fYvPcx6Qb3qRvvqhbvMa5O2/A2BCv/ETyqEedYpxOcNGj7qNrL9b7OnNxgVIokMiJhAajxBiLiR59N7zOTnor7/hrR5TvGZEcfitsRoPoZrMpKes0QlMnHBwyOUkWJAuOJP/mVX7Ak/BjQh4+YQx6So+eWCbmaEaUEdHQ9KeK5puV0ddq+2u07TV27b9aP7pSTnt16aDIYyU1+rSgNNs86mHH099XTidr8rlSt02TspLoEwWRgJQm8iElErpgKdMHoea/6H+HxxVHlNSQTFE9c6kEaLqZRMCJgH2VaNQCkqYiYNjsSPJUxdjvWdAKP8Jhvv8lIfVTb046SiLK5F5DLnMin68058vRyQ6KtCw3HRFI5EZjTmdOlAUyqRAT8QIyGWlyDyJNP0MzTuTCGEuIBPBF2hey+9OOPJtMU0/Bcp2QjGdUiLYsK3XCUUsoIaExwiZHmn2+YovfAHynbIsY2F8NPXKgI3piTLSUeZNnQ7T0LaFV2m1kcksgZ5O9JzQNXSISgT6TEyUBMn2iR5PoJn2LLjEXLCVGGE3uHfTf+DW6j7DJkSe2oYo4qml30oyQlmazILWxLCkydSJCPR0jazDvaHCL693T8805iJ9B0iCGv4wIlKD06Mn9RMRJ/VBHNKRAJhUik1BaSiYK8kRApMl1n0goicgkpEwO+kyXaJAQiRbAZyx4Pj7iaLGYN5OQB9YApvovfnE2WXA7EXB6uq2lqxsLjha7XeUeftOcLfgezLGS3Y2AMomIZZItx4hoiYls0VAaSqb0yJOIlymJkkmJSKRJK4k86ROTMSmRUSbXPaT/Iv2+kfc4Wtx+1ibSdhIMFYCrZ8K8PKs64KKkG5Stvt+AOUeT3W53gt/U+KLsGcLxSv1dNkNf+ghB6smFGBMN/Yg8R8nkZhIh00S4TExE7Cdy9ZmUJtdpWk76oM8wERTyIt4jNb/qlP5SR5Pb2wUsEEgDG9PriDR30CpoV+xI2K2xrKmKz81gHRAWHG1udy1+2+k+KjxbeDzmFUAMtAYFEEEEpdCMKYvE3ETIhhhREhq6TGpIk3GbpoWkoCRSppnKjrtUhF2a/Dxf/NzfobjKUeZ+C2hJpptagukoqCzO5pT8ZI9kXEW6OvFQfb7VeuFG/+4UXxaeK3mi7EzB8D7vKQlLvfemYJFIpBHRURoiEy0pkZvJvYSJkGUiXMoIIgHZPpp369K/GvX/5KL7Wxd8cmkL80N7QAZqgXOLs4mA2V6NcZ35Dj8SgO3WEze50vF+zoKnCD8gfJ2wRUGqIl8ACsPfTBHkZcoypaEk8iQalnZyryHlqc8nEuZMZLJ36/MbpMVXO+uam6wnPnnxNkotHKA5ZMQhbptNIXqrg3qdNCBfQqbKkndYb9zpoLO8w6JLJG+U/YrGA8SAdAlNdQhXqc/hRN+TEP1Eskxu6FpSQz9PDpMISO96pXmNfv5PjZevwUG7Tre+KDum/2JRC3eotyE3zCYLXnankT1VtKt+EKraIPe3HtllGVfgCsd5gzmPl30bHoLzhG1CEuiRBs7krCNnTO3fz4XSkZcoLXm8JNxA8xmpfZPF/o24Td7LZuuU/hRaRCVa/TzYTo3jptlEwHe9bL9vfNZV1TvfYfkykrOsd/baj7c6xTv17oNvFx4iOUdxkuQkIUnIdeRDqqboyViPZK/karpb6D6jaz5g1L8D+8w7FrjvlFiH2QvSIHeUO2eThEDj2mqarWWsxTzZvHvgduud3Tpc6mU+7/l24ky9E4w8WHGG5FzFCXonY4dksyTphGJZuBO3GbtZcp3kK8a+LFwh3OgG19F3jinSvYk6+YCB/cB5F6ffsUoBz7Rikptq+WoB6xUxevfFBx0rPF3g9kmj8X47bNPZppg3sklnq2y70KBoHTC2W7Zo3kFL9tlvr/McRAH3dmzxvG88HtVDaRp46A9kpGu4oV+lgDdYMdlH6ihXPwNq6+K4x+GDjl0O2uMgbgZLaihoALAwaXscw8xfhFPISAPymRKgRXMZzCYJgd6VRjpZO7Ai5lDtYbZYwKINjiGai4idBAKQDvPdfPFZmE0SAm/4ozt9/y/eIDtjuPxSPx+6t0X3w6dscGzwe1+/ExeTjqsEA0BSRcclRl9avYBGVkX2CdkZlWhDWTDZ8bJHHksCbrD1NJxP5HqaIwHUUfFa4tbZRkDI3i77Jo2sGYx6JJNrJ8qegtfgZhusb5730BHjR9Hed7qmRD7MUvzyPtrrYTYrogFan5bdJDtl+L1wHR09WHL/Y0HADU45C1+H+eFDMVPdOvLHOXjn6gV00KrYZJex92t8Zx35BiNidqbk62Wfwm4brGPKwylPBNJKN8tfQ3wOS6sXcLXc5FYneLfsWzXaQ0XBQ2TGWfYdslfhYzZYx6SfIW8dPp63PhEVfIX5y6weLfNWxatfsexpP/1pXC67UFtJV19ntEjOxkslX42DNlhfPGs+85gfJx5Nj4wGgQDkQ61Nu4PmnSzdavVoWbJqGpcLl0kuQJKQVrBTrvEY2dfhtTZYZzzqYtqfhuHzanq09TfVX4P/Apj9FAwv/8PbPetpb9F6rMZJh5x6m4FpufG7sr14lw3WBz/9xPNIz6VcMPxVEACpkjN/gNs/dzcEvN1dInmb7CekWsDhpkFyjuTXzbkNn7DB0eVHnngy3S/QPJk8kPnWfQAKuj9noXMXySy4S+2lv3er7PclRR54H9xUPTRajccp/kj4GsFGO0rtFy48yejAHxDPIKbkA+gBkOpr5DfQf47eXW0tvbvMnLcrLpE9UKIWsX4WZPozj5S9VNiFSxxZNnjOheebm/t5Ed+lFPo8fCi6glLddz3jV7ibpPA8d4vnPe+7ZK/QOE5T1wLRHLZE8ynJy23yBuy1wWx5wUUjtx+8WJd/RTf3eEujHbqGgyO6FqNJm0Mz6UeYRzvpRz2jF9G+DLfC7JOQYd6t8Q+yXxwWbaAlZA/UeKGxBwkvwY02mA0vPjvZv+cnjfLPyc19pGh1iMQIfRCBqNaYRdV8gfKvPO+2NYiAa8Dvuw/+QOPJGo1m4OiQKjs+xPgmxcvxDsnVvsVuhA3uOg9Ic+6xcLKDm59kvPB9utGT9S3jecYtXctiO+lHLI3QYH6qn5uKjPNX0D4Db7YGpPAca8KLXvKtsj80cnq9YHWF2fH0GTSflbxR8kHh8/a7Bb0NVs4rHC8508HRRcrCN+vnHqOb22E8oowYz9G1jBu6EYtzLDfsn0eekm5uqrUYvRDPNcysC9EDHPBW222S/ZNUZ8ArOFMQMrI5ycWSB0luknzeTp+aLAO7zC0uq2XcAL8qe7CTLblIcn+Ni3XO1XT3Y3mzQGppglToe3LDKJGCvkdmuafLRKm+kLxD8zqal1lDUniGNeMV/3uzsb/S+J7B9YFtdZ0MrvqetJDtx63Yq3EZdglflFxv5EadfTbZZ9GiHQ643RI6a0UjORz7HI7hx/Ul7AcsT9qWSX8AT5C8yYJiXmezYrODtuM4vVONnas4z9g5xk5V3FNvm142Rsl0mxlvopunTKbcbp5uxHgSCccjDoxYHtGNMJqOfJ+geQbev8YC/tgah/6/Pl7xbK2f1th5yKRkZHJ9uL66hjS8OUvSC8uS/diL/RN5x4pO0gnLsl4RKCiSgkAIAQJQBIACQqkqFNBD9U8rU+OCTlIkk15IOo3epNfqjPSTVsxZtl1nm85WvTmdkQ5jdOgnrTC5T48OBcuIxHiefp7lzZSWfo7xHOMR/YguT8YtB0YszhMjjJZp3kf78/iCNaZl2Zry0z9wq7/+xz/Vu4fkB2WbpgXSACDVAtUSDok2eL+RbJJsEo6XAJBhYBxqSIhqL3Cu+vqfU6rPUr1/p+pLFfXrxLPUfxZT9+oEtT65ISOQEEHuJ30hCqmQe9pMZHKiKfQYoevpEpHfTXoBy18wA5rnuS/6tW1vvGCPb7r001rLssfK1eaple0nGfgqsvrXDoibhzbyV2OHuVb9Mw0cEqAaD/0AlcEvHq/GU00luWm5phoUpKHPE9FSEjEiT+RLiciYjFOmz6T0AX1+Fv3H6M2itSybCT/5Lbu84g1/YKvjZD8jaWVAMtys4p76eqoF6s+h/jxXf2n1rxtaDFzLkRGVeHVUSmiq6FpgIPJNmrb69dDXP5T1hrXqB7gUdKSgDXT0GUhIQQ6aQilhLv7DUnqhhfGnzZAUC19vprzorfNO8lTZL8keKlsYPl1/OIoMnRA7LOXgtDp8LwAO9y35A/cC9cFFZar11XWPbqovU/0YPZaZ3J+Mq8/HKFhGX///qnvjhrIwef5bYJKE6OfoJ4nHuPmCfuFvHPAK3GnGpDju8Y4If/nui7V+UfLtki1TEq5MwPoahjdqrZZhAROiaqpxLWUcRryYEqNDUcs4fD1GX40nvVJ93mM89Vk/STTKiH7LRL55xv9Pv2zcXGLc/J5rPvo69MyeFI4gr3NPje/S+DHZQySN5lDPcQNjh5u6hyQcmlprKukMSjcsYR0J+1UK2A3IOK7v121KuB4F40rAwPKIfoGyQDeiW6Af7TKe/1vj5m34kCNIivMf4ojyG59acLIHCN8t+wHZSZoBqepkhGEpwYCIUY9XEQUZFhAKYiXT8ICM40rIMeopNyZ9merHA5Gy/mcsI6Y/z5RN9JvoR2F54dW60d8po/e69NL9iCMroKPI22y3yc/qfbXs3rKTZK00FAWrxnCvygZV1xCwwnEMjAtU4qkiYKnFq6fdKmr1dUQbeCbsUI/rX9erx7fq5m5W5t9mPP+v+ISjSIqHH++o8uFbk/9yJp6o8RjJIzROk2yXhhOSgRpfLd4AqxDycBGxwGGm4BiKgJU0dTG5FqnDUvVrp5KPQXE7S4qr9a6w5D/wHjf7LJYdZVLc3/rheTY51X1wgeSrJs+JD5bskKRVZb9phVmwVdwrqBMTA5GvAOpMuKvGQ+L0hrPeOtKN1fKGzgG9qy15r3ApPmXRNbjWOiLFU60/fk2rsdOc4ySn4GxcqHFv2b1wFrbIsAIJoxJwSMSEAitIRADq+329kLiOgPUUXD+jUQs5uQ7Tny+bFrbTu87Y1RZ9QXKpzuUW3WLO9Tp3YNk6JMV3Ora4QPY9ttjteK1tGmfKTsAWybx+0mfzipF20tNKWiEjS7IyuSbJCAmUybhM3WO4LggqAXskoUcPQqATOhShCJ0i9DpFr1jS6U2asbFFnWWdJWOLegd1Dhq7TXGj3k16d9hlN3orZ0PADTbI/v/KBhsCbrDBhoAbbAi4wQYbAm6wIeAGG2wIuMGGgBtssCHgBhsCbrDB/wlKajuIhIz6AQAAAABJRU5ErkJggg==', width=50, height=50,image_fit=ft.ImageFit.CONTAIN, bgcolor=ft.colors.WHITE, border_radius=ft.border_radius.all(20), border=ft.BorderSide(0.2, ft.colors.BLACK45),
                                                                               shadow=BoxShadow(1,10, ft.colors.BLACK45, None, ShadowBlurStyle.NORMAL)),
                                                               ])
                                                       ]
                                                   )
                                               ]
                                           )),

                                       ]##
                                   ),
                                   
                                    
                               ],
                               run_spacing=-10, spacing=-10

                           ),
                           
                
                       ], 
                       # Controls
                       scroll=ft.ScrollMode.ADAPTIVE

                       )  # ft.view

    Dialog = AlertDialog(open=False, modal=True, title=ft.Text("Succesfully Created a Account", color=ft.colors.PINK_200), content=ft.Container(width=200, height=200, gradient=ft.LinearGradient(colors=['#ffb4fe', '#fbe5fe'], rotation=90)))
    RecvrAccDia = AlertDialog(
        open=False, title=Text(size=25, text_align=TextAlign.CENTER, width=500,weight=ft.FontWeight.BOLD, offset=ft.Offset(x=0, y=0.35), color=ft.colors.WHITE, spans=[ft.TextSpan("Enter the code from your email and confirm your password.",
                                                TextStyle(shadow=ft.BoxShadow(1,5,ft.colors.PINK_300, blur_style=ShadowBlurStyle.OUTER),color=ft.colors.PINK_200,
                                                                        foreground=ft.Paint(color=ft.colors.WHITE, stroke_width=0.1, stroke_join=StrokeJoin.ROUND)))]),
        content=ResponsiveRow([TextField(label='Password', border_radius=15, border_color=ft.colors.PINK_300, col={'xs': 12, 'sm': 8, 'md': 10, 'lg': 8, 'xl': 4}, scale=0.9,text_align=ft.TextAlign.CENTER,suffix_icon=ft.icons.NUMBERS,keyboard_type=ft.KeyboardType.NUMBER,
                                                               text_style=ft.TextStyle(color=ft.colors.PINK_300), on_change=_SetPassword),
                               
                               TextField(label='Code' ,border_radius=15, border_color=ft.colors.PINK_300, col={'xs': 12, 'sm': 8, 'md': 10, 'lg': 8, 'xl': 4}, scale=0.9,text_align=ft.TextAlign.CENTER,suffix_icon=ft.icons.NUMBERS, password=True,
                                                               text_style=ft.TextStyle(color=ft.colors.PINK_300), on_change=_SetPassword),
                               
                               
                               ]),
        actions=[
            ResponsiveRow([
                TextButton("Enter", style=ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.GREEN_400}, color={
                                                               ft.MaterialState.DEFAULT: ft.colors.WHITE}, shape=ft.RoundedRectangleBorder(radius=5)), col={'xs': 5.5, 'sm': 5.5, 'md': 5.5, 'lg': 5.5, 'xl': 5.5}, scale=0.8, height=50),
                TextButton("Cancel", style=ButtonStyle(bgcolor={ft.MaterialState.DEFAULT: ft.colors.RED_400}, color={
                                                               ft.MaterialState.DEFAULT: ft.colors.WHITE}, shape=ft.RoundedRectangleBorder(radius=5)), col={'xs': 5.5, 'sm': 5.5, 'md': 5.5, 'lg': 5.5, 'xl': 5.5}, scale=0.8, height=50),
                                           
            ], alignment=ft.MainAxisAlignment.CENTER)
        ]                                
                              
                                          
                                          )
    def UpdatePg(route):
        


        print(route)
        page.views.clear()
        page.views.append(LoginPg())
        print(page.route+" Hello World")
        

        

        if page.route == "/register":
            page.views.clear()
            page.views.append(RegisterPg())
            

        if page.route == "/login":
            print("... : Your are on the login Page")
            page.views.clear()
            page.views.append(LoginPg())
        if page.route == "/Recover":
            print("... : Your are on the login Page")
            page.views.clear()
            page.views.append(RecoverPg())
         
        if page.route == "/Main":
            page.views.clear()
            page.views.append(MainPg())
            page.update()
            print("Main Page")
        if page.route == "/Book":
            page.views.clear()
            page.views.append(BookingPg())
            print("Booking knotless")
        if page.route == "/Book2":
            print("Booking knotless")

    page.on_route_change = UpdatePg
    page.go("/Register")
pass

app(target=LoginScreen, port=7123, view="web_browser")

